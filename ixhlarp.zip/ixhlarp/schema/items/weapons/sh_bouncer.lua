ITEM.name = "Bouncer"
ITEM.description = "A small combine make grenade, that when thrown makes an audible countdown then explodes."
ITEM.model = "models/hlvr/weapons/grenade/w_grenade.mdl"
ITEM.class = "tfa_combeangren"
ITEM.weaponCategory = "grenade"
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 1

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end