ITEM.name = "Medishot"
ITEM.description = "A simple injection of medical fluid for the purpose of healing wounds."
ITEM.category = "Medical Items"
ITEM.bDropOnDeath = true

ITEM.model = "models/weapons/w_medishot.mdl"
ITEM.skin = 0
ITEM.width = 1
ITEM.height = 2

ITEM.price = 50000
ITEM.flag = "0"

-- Weapon Statistics

ITEM.class = "tfa_healthshot"
ITEM.weaponCategory = "Medical"

-- Weapon Code

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("combineOnly"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end