ITEM.name = "Supressor Heavy Machine Gun"
ITEM.description = "A large heavy machine gun that fires fast while making movement hard."
ITEM.category = "Weapons (HMG)"

ITEM.model = "models/hlvr/weapons/w_suppressor/suppressor_weapon_hlvr.mdl"
ITEM.skin = 0
ITEM.width = 7
ITEM.height = 3

ITEM.price = 50000
ITEM.flag = "0"

-- Weapon Statistics

ITEM.class = "tfa_suppressor"
ITEM.weaponCategory = "HMG"

-- Weapon Code

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end