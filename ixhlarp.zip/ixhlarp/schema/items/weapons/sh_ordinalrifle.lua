ITEM.name = "Command Issue Overwatch Rifle"
ITEM.description = "A light rifle that has a neat sleek design and is made for combat effectiveness."
ITEM.category = "Weapons (Rifles)"

ITEM.model = "models/weapons/w_ordinalrifle.mdl"
ITEM.skin = 0
ITEM.width = 5
ITEM.height = 2

ITEM.price = 50000
ITEM.flag = "0"

-- Weapon Statistics

ITEM.class = "tfa_ordinalrifle"
ITEM.weaponCategory = "Rifle"

-- Weapon Code

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end