ITEM.name = "Standard Issue Overwatch Shotgun"
ITEM.description = "A Heavy shotgun that has a slow firerate but packs a large punch."
ITEM.category = "Weapons (Shotguns)"

ITEM.model = "models/hlvr/weapons/w_shotgun_heavy/w_shotgun_heavy_hlvr.mdl"
ITEM.skin = 0
ITEM.width = 5
ITEM.height = 2

ITEM.price = 50000
ITEM.flag = "0"

-- Weapon Statistics

ITEM.class = "tfa_heavyshotgun"
ITEM.weaponCategory = "SHOTGUN"

-- Weapon Code

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end