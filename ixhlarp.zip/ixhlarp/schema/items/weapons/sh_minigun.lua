--[[---------------------------------------------------------------------------
	** Copyright (c) 2021 Connor ---- (ZIKE)
	** This file is private and may not be shared, downloaded, used, sold or even copied.
	** Allowed Users to use any of this products code: ZIKE#7537
---------------------------------------------------------------------------]]--

-- Item Statistics

ITEM.name = "Minigun"
ITEM.description = "A Big Machine Gun with it's color being bright white & grayish. It's super heavy."
ITEM.category = "Weapons (LMGs)"

ITEM.model = "models/weapons/w_hwy_mg.mdl"
ITEM.skin = 0

ITEM.width = 8
ITEM.height = 4

ITEM.price = 50000
ITEM.flag = "0"

-- Weapon Statistics

ITEM.class = "oc_lmg_minigun"
ITEM.weaponCategory = "LMG"

-- Weapon Code

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end