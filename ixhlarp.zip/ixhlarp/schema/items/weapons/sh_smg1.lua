ITEM.name = "MP7"
ITEM.description = "An SMG Fabricated By Heckler And Koch, very notorious for it's design."
ITEM.model = "models/weapons/tfa_ins2/w_mp7.mdl"
ITEM.class = "tfa_ins2_mp7"
ITEM.weaponCategory = "smg"
ITEM.width = 3
ITEM.height = 2
ITEM.iconCam = {
	ang	= Angle(-0.020070368424058, 270.40155029297, 0),
	fov	= 7.2253324508038,
	pos	= Vector(0, 200, -1)
}

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end