ITEM.name = "Grenade"
ITEM.description = "A small, green colored MK3A2 grenade that explodes a few seconds after it is thrown."
ITEM.model = "models/weapons/w_grenade.mdl"
ITEM.class = "weapon_frag"
ITEM.weaponCategory = "grenade"
ITEM.classes = {CLASS_EOW}
ITEM.flag = "V"
ITEM.width = 1
ITEM.height = 1

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end