ITEM.name = "Calico M950"
ITEM.description = "A Calico M950."
ITEM.category = "Weapons (SMGs)"

ITEM.model = "models/weapons/tfa_l4d2/w_calico.mdl"
ITEM.skin = 0
ITEM.width = 2
ITEM.height = 2

ITEM.price = 50000
ITEM.flag = "0"

-- Weapon Statistics

ITEM.class = "tfa_l4d2_calico"
ITEM.weaponCategory = "SMG"

-- Weapon Code

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText(L("illegalItem"))
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end