ITEM.name = "UU Forcefield Pass"
ITEM.description = "A card given to loyalists and members of the CWU to bypass restricted areas for work. This card is assigned to %s"
ITEM.category = "Tools"

ITEM.model = "models/gibs/metal_gib4.mdl"
ITEM.skin = 0

ITEM.width = 2
ITEM.height = 1

ITEM.price = 1000
ITEM.noBusiness = false

function ITEM:GetDescription()
	return string.format(self.description, self:GetData("name", "nobody"))
end