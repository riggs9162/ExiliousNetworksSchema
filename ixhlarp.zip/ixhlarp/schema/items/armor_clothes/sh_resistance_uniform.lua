
ITEM.name = "Resistance Uniform"
ITEM.description = "A resistance uniform with a symbol on the sleeve."
ITEM.category = "Clothing"
ITEM.flag = "v"
ITEM.model = "models/tnb/items/shirt_rebel1.mdl"
ITEM.maxArmor = 40

ITEM.bodyGroups = {
	["torso"] = 9,
}
