-- Item Statistics

ITEM.name = "EMP Tool"
ITEM.description = "Can be used to bypass combine technology and defensive doors."
ITEM.category = "Weapons (Equipment)"

ITEM.model = "models/alyx_emptool_prop.mdl"
ITEM.skin = 0

ITEM.width = 1
ITEM.height = 1

ITEM.price = 1000
ITEM.noBusiness = false

-- Functions

ITEM.functions.Hack = {
	name = "Hack",
	icon = "icon16/tick.png",
	OnRun = function(itemstat)
		local client = itemstat.player
		local data = {}
			data.start = client:GetShootPos()
			data.endpos = data.start + client:GetAimVector() * 96
			data.filter = client
		local target = util.TraceLine(data).Entity
		if (IsValid(target)) then
			if (target:IsDoor()) then
				itemstat.bBeingUsed = true
				client:Freeze(true)
				client:SetAction("Overloading...", 2)
				client:DoStaredAction(target, function()
					local chance = math.random(1, 10)

					if chance > 5 then
						target:Fire("open", "", 0)
						target:Fire("setanimation", "open", 0)
						if (target:IsLocked()) then
							target:Fire("unlock", "", 0)
						end
						target:EmitSound("ambient/energy/weld1.wav")
						client:Notify("You have successfully overloaded the door.")
					else
						target:EmitSound("ambient/energy/newspark0"..math.random(1,9)..".wav")
						client:Notify("The EMP attempt failed.")
					end
					client:Freeze(false)
				end, 2, function()
					client:SetAction()
					itemstat.bBeingUsed = false
				end)
			else
				client:Notify("You need to look at a door first.")
			end
		end
		
		return false
	end,
	OnCanRun = function(itemstat)
		return !IsValid(itemstat.entity) or itemstat.bBeingUsed
	end
}

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText("This item is illegal.")
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end