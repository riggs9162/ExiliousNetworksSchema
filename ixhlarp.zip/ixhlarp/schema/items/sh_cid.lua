ITEM.name = "Citizen Identification Card"
ITEM.description = "A citizen identification card\nID number: #%s\n This ID is assigned to %s."
ITEM.category = "Tools"
ITEM.bDropOnDeath = true

ITEM.model = "models/gibs/metal_gib4.mdl"
ITEM.skin = 0

ITEM.width = 2
ITEM.height = 1

ITEM.price = 1000
ITEM.noBusiness = false

function ITEM:GetDescription()
	return string.format(self.description, self:GetData("id", "00000"), self:GetData("name", "nobody"))
end