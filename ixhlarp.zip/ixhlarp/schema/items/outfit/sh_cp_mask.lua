ITEM.name = "Civil Protection Suit"
ITEM.description = "A Civil Protection Suit with a gasmask intergrated into it."
ITEM.category = "Suits"
ITEM.model = "models/props_junk/cardboard_box003a.mdl"
ITEM.width = 1
ITEM.height = 2
ITEM.outfitCategory = "suit"

ITEM.replacements = "models/ma/hla/metropolice.mdl"

ITEM.iconCam = {
	pos = Vector(-30, 2, -2.7999999523163),
	ang = Angle(0, -0, 90),
	fov = 45,
}

function ITEM:PopulateTooltip(tooltip)
    local warning = tooltip:AddRow("warning")
    warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
    warning:SetText("This item is illegal.")
    warning:SetFont("BudgetLabel")
    warning:SetExpensiveShadow(0.5)
    warning:SizeToContents()
end