CLASS.name = "MPF UNION"
CLASS.faction = FACTION_CP
CLASS.isDefault = true

CLASS_UNION = CLASS.index