CLASS.name = "Resistance Member"
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = false

function CLASS:CanSwitchTo(client)
	return false
end

CLASS_RMEMBER = CLASS.index