CLASS.name = "Overwatch XRAY"
CLASS.faction = FACTION_OTA
CLASS.isDefault = false

function CLASS:CanSwitchTo(client)
    return client:HasClassWhitelist(self.index)
end

function CLASS:OnSet(client)
	local character = client:GetCharacter()
    local inventory = character:GetInventory()
    local model = "models/hlvr/characters/combine/heavy/combine_heavy_hlvr_npc.mdl"
    client:SetMaxArmor(70)
    client:SetMaxHealth(100)
    
	if (character and (character:GetModel() != model)) then
		character:SetModel(model)
        inventory:Add("heavyshotgun",1)
        inventory:Add("shotgunammo",2)
        inventory:Add("zip_tie",1)
        inventory:Add("medishot",1)
        client:SetArmor(60)
        client:SetHealth(100)
	end
end

CLASS_XRAY = CLASS.index