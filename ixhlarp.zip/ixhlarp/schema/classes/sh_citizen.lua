CLASS.name = "Citizen"
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = true

function CLASS:CanSwitchTo(client)
	return false
end

CLASS_CITIZEN = CLASS.index