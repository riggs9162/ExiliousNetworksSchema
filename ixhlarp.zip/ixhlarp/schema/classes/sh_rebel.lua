CLASS.name = "Rebel"
CLASS.faction = FACTION_CITIZEN
CLASS.isDefault = false

function CLASS:CanSwitchTo(client)
	return false
end

CLASS_REBEL = CLASS.index