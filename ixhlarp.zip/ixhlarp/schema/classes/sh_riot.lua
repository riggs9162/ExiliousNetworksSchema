CLASS.name = "Overwatch RIOT"
CLASS.faction = FACTION_OTA
CLASS.isDefault = false

function CLASS:CanSwitchTo(client)
    return client:HasClassWhitelist(self.index)
end

function CLASS:OnSet(client)
	local character = client:GetCharacter()
    local inventory = character:GetInventory()
    local model = "models/hlvr/characters/combine_captain/combine_captain_hlvr_npc.mdl"
    client:SetMaxArmor(80)
    client:SetMaxHealth(100)
    
	if (character and (character:GetModel() != model)) then
		character:SetModel(model)
        inventory:Add("ordinalrifle",1)
        inventory:Add("rifleammo",2)
        inventory:Add("zip_tie",1)
        inventory:Add("medishot",1)
        client:SetArmor(80)
        client:SetHealth(100)
	end
end

CLASS_RIOT = CLASS.index