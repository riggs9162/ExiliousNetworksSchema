CLASS.name = "MPF GRID"
CLASS.faction = FACTION_CP
CLASS.isDefault = false

function CLASS:CanSwitchTo(client)
    return client:HasClassWhitelist(self.index)
end

function CLASS:OnSet(client)
    local char = client:GetCharacter()
    char:GiveFlags("pet")

end

function CLASS:OnLeave(client)
    local char = client:GetCharacter()
    char:TakeFlags("pet")
end

CLASS_GRID = CLASS.index