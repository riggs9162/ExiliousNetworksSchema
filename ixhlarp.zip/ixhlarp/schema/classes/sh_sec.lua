CLASS.name = "MPF SECTORIAL"
CLASS.faction = FACTION_CP
CLASS.isDefault = false

function CLASS:CanSwitchTo(client)
    return client:HasClassWhitelist(self.index)
end

CLASS_SEC = CLASS.index