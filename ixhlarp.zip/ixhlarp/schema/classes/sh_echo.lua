CLASS.name = "Overwatch ECHO"
CLASS.faction = FACTION_OTA
CLASS.isDefault = false

function CLASS:OnSet(client)
	local character = client:GetCharacter()
    local inventory = character:GetInventory()
    local model = "models/hlvr/characters/combine/grunt/combine_grunt_hlvr_npc.mdl"
    client:SetMaxArmor(60)
    client:SetMaxHealth(100)

	if (character and (character:GetModel() != model)) then
		character:SetModel(model)
        inventory:Add("gruntsmg",1)
        inventory:Add("smg1ammo",2)
        inventory:Add("zip_tie",1)
        inventory:Add("medishot",1)
        client:SetHealth(100)
        client:SetArmor(60)
	end
end

CLASS_ECHO = CLASS.index