CLASS.name = "Overwatch HONOR"
CLASS.faction = FACTION_OTA
CLASS.isDefault = false

function CLASS:CanSwitchTo(client)
    return client:HasClassWhitelist(self.index)
end

function CLASS:OnSet(client)
	local character = client:GetCharacter()
    local inventory = character:GetInventory()
    local model = "models/combine_super_soldierproto.mdl"
    client:SetMaxArmor(120)
    client:SetMaxHealth(100)

	if (character and (character:GetModel() != model)) then
		character:SetModel(model)
        inventory:Add("ordinalrifle",1)
        inventory:Add("rifleammo",2)
        inventory:Add("zip_tie",1)
        inventory:Add("medishot",1)
        client:SetHealth(100)
        client:SetArmor(120)
	end
end

CLASS_HONOR = CLASS.index