FACTION.name = "Metropolice Force"
FACTION.description = "A metropolice unit working as Civil Protection."
FACTION.color = Color(50, 100, 150)
FACTION.isGloballyRecognized = true
FACTION.isDefault = false
FACTION.payTime = 3600
FACTION.pay = 10

FACTION.models = {"models/police.mdl"}

FACTION.npcRelations = {
	-- Combine
	["npc_combine_camera"] = D_LI,
	["npc_turret_ceiling"] = D_LI,
	["npc_cscanner"] = D_LI,
	["npc_combinedropship"] = D_LI,
	["npc_combinegunship"] = D_LI,
	["npc_combine_s"] = D_LI,
	["npc_helicopter"] = D_LI,
	["npc_metropolice"] = D_LI,
	["npc_rollermine"] = D_LI,
	["npc_clawscanner"] = D_LI,
	["npc_stalker"] = D_LI,
	["npc_strider"] = D_LI,
	["npc_turret_floor"] = D_LI,
	["npc_manhack"] = D_LI,
	["npc_hunter"] = D_LI,
	-- Rebels
	["npc_citizen"] = D_HT,
	["npc_vortigaunt"] = D_HT
}
--[[
function FACTION:OnCharacterCreated(ply, char)
	local id = math.random(00001,99999)
	char:SetData("cid", id) -- For off-duty ranks.
	char:SetData("cmbName", self:GetDefaultName()) -- Name that was set on Charcreation.
	char:SetData("unitType", "") --For saving class
end
]]--
function FACTION:GetDefaultName(ply)
	return "MPF-UNION.RCT:" .. math.random(1, 999), true
end

function CPGear(ply, char, inventory)
	ply:CleanInventory()

	for i, v in pairs(Schema.CP_RankTable) do
		if string.match(ply:GetName(), i) then

			for i2, v2 in pairs(v) do
				if string.match(ply:GetName(), i2) then
					print("Set Model to: " .. v2[1])
					char:SetModel(v2[1])
					char:SetClass(v2[2])
					ply:SetMaxArmor(v2[4])

					for _, wep in ipairs(v2[3]) do
						inventory:Add(wep)
					end
				end
			end
		end
	end
end

function FACTION:OnTransfered(ply)
	local char = ply:GetCharacter()
	local inventory = char:GetInventory()
	char:SetName(self:GetDefaultName())
	CPGear(ply, char, inventory)
end

function FACTION:OnCharacterCreated(ply)
	local char = ply:GetCharacter()
	local inventory = char:GetInventory()
	CPGear(ply, char, inventory)
end

function FACTION:OnNameChanged(ply)
	local char = ply:GetCharacter()
	local inventory = char:GetInventory()
	CPGear(ply, char, inventory)
end
FACTION_CP = FACTION.index