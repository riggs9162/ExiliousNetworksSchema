FACTION.name = "Citizen"
FACTION.description = "A regular human citizen enslaved by the Universal Union."
FACTION.color = Color(150, 125, 100)
FACTION.isGloballyRecognized = false
FACTION.isDefault = true
FACTION.payTime = 1
FACTION.pay = 0

FACTION.models = {
	"models/tnb/citizens/male_01.mdl",
	"models/tnb/citizens/male_02.mdl",
	"models/tnb/citizens/male_03.mdl",
	"models/tnb/citizens/male_04.mdl",
	"models/tnb/citizens/male_05.mdl",
	"models/tnb/citizens/male_06.mdl",
	"models/tnb/citizens/male_07.mdl",
	"models/tnb/citizens/male_08.mdl",
	"models/tnb/citizens/male_09.mdl",
	"models/tnb/citizens/male_10.mdl",
	"models/tnb/citizens/male_11.mdl",
	"models/tnb/citizens/male_12.mdl",
	"models/tnb/citizens/male_13.mdl",
	"models/tnb/citizens/male_14.mdl",
	"models/tnb/citizens/male_15.mdl",
	"models/tnb/citizens/male_16.mdl",
	"models/tnb/citizens/male_17.mdl",
	"models/tnb/citizens/male_18.mdl",
	"models/tnb/citizens/female_01.mdl",
	"models/tnb/citizens/female_02.mdl",
	"models/tnb/citizens/female_03.mdl",
	"models/tnb/citizens/female_04.mdl",
	"models/tnb/citizens/female_06.mdl",
	"models/tnb/citizens/female_07.mdl",
	"models/tnb/citizens/female_08.mdl",
	"models/tnb/citizens/female_09.mdl",
	"models/tnb/citizens/female_10.mdl",
	"models/tnb/citizens/female_11.mdl"
}

FACTION.npcRelations = {
    -- Combine
    ["npc_combine_camera"] = D_HT,
    ["npc_turret_ceiling"] = D_HT,
    ["npc_cscanner"] = D_HT,
    ["npc_combinedropship"] = D_HT,
    ["npc_combinegunship"] = D_HT,
    ["npc_combine_s"] = D_HT,
    ["npc_helicopter"] = D_HT,
    ["npc_metropolice"] = D_HT,
    ["npc_rollermine"] = D_HT,
    ["npc_clawscanner"] = D_HT,
    ["npc_stalker"] = D_HT,
    ["npc_strider"] = D_HT,
    ["npc_turret_floor"] = D_HT,
    ["npc_manhack"] = D_HT,
    ["npc_hunter"] = D_HT,
    -- Rebels
    ["npc_citizen"] = D_LI,
    ["npc_vortigaunt"] = D_LI
}

function FACTION:OnCharacterCreated(ply, char)
	local inventory = char:GetInventory()
	local id = math.random(00001,99999)
	
	char:SetData("cid", id)
	
	inventory:Add("suitcase", 1)
	inventory:Add("cid", 1, {
		name = char:GetName(),
		id = id
	})
end

FACTION_CITIZEN = FACTION.index