FACTION.name = "Civil Worker's Union"
FACTION.description = "A enslaved citizen that has earned their loyalty to the universal union."
FACTION.color = Color(170, 170, 170)
FACTION.isGloballyRecognized = false
FACTION.isDefault = true
FACTION.payTime = 1
FACTION.pay = 0

FACTION.models = {
	"models/player/hl2rp/male_01.mdl",
	"models/player/hl2rp/male_02.mdl",
	"models/player/hl2rp/male_03.mdl",
	"models/player/hl2rp/male_04.mdl",
	"models/player/hl2rp/male_05.mdl",
	"models/player/hl2rp/male_06.mdl",
	"models/player/hl2rp/male_07.mdl",
	"models/player/hl2rp/male_08.mdl",
	"models/player/hl2rp/male_09.mdl",
	"models/player/hl2rp/female_01.mdl",
	"models/player/hl2rp/female_02.mdl",
	"models/player/hl2rp/female_03.mdl",
	"models/player/hl2rp/female_04.mdl",
	"models/player/hl2rp/female_06.mdl",
	"models/player/hl2rp/female_07.mdl"
}

FACTION.npcRelations = {
    -- Combine
    ["npc_combine_camera"] = D_LI,
    ["npc_turret_ceiling"] = D_LI,
    ["npc_cscanner"] = D_LI,
    ["npc_combinedropship"] = D_LI,
    ["npc_combinegunship"] = D_LI,
    ["npc_combine_s"] = D_LI,
    ["npc_helicopter"] = D_LI,
    ["npc_metropolice"] = D_LI,
    ["npc_rollermine"] = D_LI,
    ["npc_clawscanner"] = D_LI,
    ["npc_stalker"] = D_LI,
    ["npc_strider"] = D_LI,
    ["npc_turret_floor"] = D_LI,
    ["npc_manhack"] = D_LI,
    ["npc_hunter"] = D_LI,
    -- Rebels
    ["npc_citizen"] = D_LI,
    ["npc_vortigaunt"] = D_LI
}

function FACTION:OnCharacterCreated(ply, char)
	local inventory = char:GetInventory()
	local id = math.random(00001,99999)
	
	char:SetData("cid", id)
	
	inventory:Add("suitcase", 1)
	inventory:Add("cid", 1, {
		name = char:GetName(),
		id = id
	})
end

FACTION_CWU = FACTION.index