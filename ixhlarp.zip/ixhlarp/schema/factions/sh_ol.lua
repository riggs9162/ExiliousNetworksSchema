FACTION.name = "Overlook"
FACTION.description = "One of the most powerful members of the Universal Union."
FACTION.color = Color(50, 50, 200)
FACTION.isGloballyRecognized = true
FACTION.isDefault = false
FACTION.payTime = 3600
FACTION.pay = 10

FACTION.models = {
    "models/humans/combine/female_01.mdl",
    "models/humans/combine/female_02.mdl",
    "models/humans/combine/female_03.mdl",
    "models/humans/combine/female_04.mdl",
    "models/humans/combine/female_06.mdl",
    "models/humans/combine/female_07.mdl",
    "models/humans/combine/female_ga.mdl",
    "models/humans/combine/male_01.mdl",
    "models/humans/combine/male_02.mdl",
    "models/humans/combine/male_03.mdl",
    "models/humans/combine/male_04.mdl",
    "models/humans/combine/male_05.mdl",
    "models/humans/combine/male_06.mdl",
    "models/humans/combine/male_07.mdl",
    "models/humans/combine/male_08.mdl",
    "models/humans/combine/male_09.mdl"
}

FACTION.npcRelations = {
	-- Combine
	["npc_combine_camera"] = D_LI,
	["npc_turret_ceiling"] = D_LI,
	["npc_cscanner"] = D_LI,
	["npc_combinedropship"] = D_LI,
	["npc_combinegunship"] = D_LI,
	["npc_combine_s"] = D_LI,
	["npc_helicopter"] = D_LI,
	["npc_metropolice"] = D_LI,
	["npc_rollermine"] = D_LI,
	["npc_clawscanner"] = D_LI,
	["npc_stalker"] = D_LI,
	["npc_strider"] = D_LI,
	["npc_turret_floor"] = D_LI,
	["npc_manhack"] = D_LI,
	["npc_hunter"] = D_LI,
	-- Rebels
	["npc_citizen"] = D_HT,
	["npc_vortigaunt"] = D_HT
}

function FACTION:GetDefaultName(ply)
	return "UU-NAME." .. math.random(1, 999), true
end

function FACTION:OnTransfered(ply)
	local char = ply:GetCharacter()
	
	char:SetName(self:GetDefaultName())
end

FACTION_OL = FACTION.index