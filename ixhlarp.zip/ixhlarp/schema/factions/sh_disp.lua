FACTION.name = "Dispatch"
FACTION.description = "The Dispatcher for the entire Combine."
FACTION.color = Color(68, 68, 68)
FACTION.isGloballyRecognized = true
FACTION.isDefault = false
FACTION.payTime = 3600
FACTION.pay = 200

FACTION.models = {"models/Combine_Scanner.mdl"}

FACTION.npcRelations = {
	-- Combine
	["npc_combine_camera"] = D_LI,
	["npc_turret_ceiling"] = D_LI,
	["npc_cscanner"] = D_LI,
	["npc_combinedropship"] = D_LI,
	["npc_combinegunship"] = D_LI,
	["npc_combine_s"] = D_LI,
	["npc_helicopter"] = D_LI,
	["npc_metropolice"] = D_LI,
	["npc_rollermine"] = D_LI,
	["npc_clawscanner"] = D_LI,
	["npc_stalker"] = D_LI,
	["npc_strider"] = D_LI,
	["npc_turret_floor"] = D_LI,
	["npc_manhack"] = D_LI,
	["npc_hunter"] = D_LI,
	-- Rebels
	["npc_citizen"] = D_HT,
	["npc_vortigaunt"] = D_HT
}

function FACTION:GetDefaultName(ply)
	return "UU-DISPATCH." .. math.random(1, 999), true
end

function FACTION:OnTransfered(ply)
	local char = ply:GetCharacter()
	
	char:SetName(self:GetDefaultName())
	char:SetModel(self.models[1])
end

FACTION_DISP = FACTION.index