FACTION.name = "District Administrations"
FACTION.description = "This group of citizens have been appointed into power."
FACTION.color = Color(255, 0, 0)
FACTION.isGloballyRecognized = false
FACTION.isDefault = false
FACTION.payTime = 1
FACTION.pay = 0

FACTION.models = {
	"models/humans/combine/male_03.mdl"
}

FACTION.npcRelations = {
    -- Combine
    ["npc_combine_camera"] = D_LI,
    ["npc_turret_ceiling"] = D_LI,
    ["npc_cscanner"] = D_LI,
    ["npc_combinedropship"] = D_LI,
    ["npc_combinegunship"] = D_LI,
    ["npc_combine_s"] = D_LI,
    ["npc_helicopter"] = D_LI,
    ["npc_metropolice"] = D_LI,
    ["npc_rollermine"] = D_LI,
    ["npc_clawscanner"] = D_LI,
    ["npc_stalker"] = D_LI,
    ["npc_strider"] = D_LI,
    ["npc_turret_floor"] = D_LI,
    ["npc_manhack"] = D_LI,
    ["npc_hunter"] = D_LI,
    -- Rebels
    ["npc_citizen"] = D_HT,
    ["npc_vortigaunt"] = D_HT
}

FACTION_DA = FACTION.index