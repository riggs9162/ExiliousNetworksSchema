FACTION.name = "Combine Engineering Core"
FACTION.description = 'A Human in a Hazard suit, helps the Combine contruction arm, "GRID".'
FACTION.color = Color(124, 126, 0)
FACTION.isGloballyRecognized = false
FACTION.isDefault = false
FACTION.payTime = 3600
FACTION.pay = 10
FACTION.models = {"models/hlvr/characters/hazmat_worker/npc/hazmat_worker_citizen.mdl"}

function FACTION:GetDefaultName(ply)
    return "CEC-RANK:" .. math.random(1, 999) .. ".NAME", true
end

FACTION.npcRelations = {
	-- Combine
	["npc_combine_camera"] = D_LI,
	["npc_turret_ceiling"] = D_LI,
	["npc_cscanner"] = D_LI,
	["npc_combinedropship"] = D_LI,
	["npc_combinegunship"] = D_LI,
	["npc_combine_s"] = D_LI,
	["npc_helicopter"] = D_LI,
	["npc_metropolice"] = D_LI,
	["npc_rollermine"] = D_LI,
	["npc_clawscanner"] = D_LI,
	["npc_stalker"] = D_LI,
	["npc_strider"] = D_LI,
	["npc_turret_floor"] = D_LI,
	["npc_manhack"] = D_LI,
	["npc_hunter"] = D_LI,
	-- Rebels
	["npc_citizen"] = D_LI,
	["npc_vortigaunt"] = D_LI
}

FACTION_CEC = FACTION.index