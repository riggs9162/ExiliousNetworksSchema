FACTION.name = "Overwatch Transhuman Arm"
FACTION.description = "A transhuman Overwatch soldier produced by the Combine."
FACTION.color = Color(150, 50, 50)
FACTION.isGloballyRecognized = true
FACTION.isDefault = false
FACTION.payTime = 3600
FACTION.pay = 40

FACTION.models = {"models/hlvr/characters/combine/grunt/combine_grunt_hlvr_npc.mdl"}

FACTION.npcRelations = {
	-- Combine
	["npc_combine_camera"] = D_LI,
	["npc_turret_ceiling"] = D_LI,
	["npc_cscanner"] = D_LI,
	["npc_combinedropship"] = D_LI,
	["npc_combinegunship"] = D_LI,
	["npc_combine_s"] = D_LI,
	["npc_helicopter"] = D_LI,
	["npc_metropolice"] = D_LI,
	["npc_rollermine"] = D_LI,
	["npc_clawscanner"] = D_LI,
	["npc_stalker"] = D_LI,
	["npc_strider"] = D_LI,
	["npc_turret_floor"] = D_LI,
	["npc_manhack"] = D_LI,
	["npc_hunter"] = D_LI,
	-- Rebels
	["npc_citizen"] = D_HT,
	["npc_vortigaunt"] = D_HT
}

function FACTION:GetDefaultName(ply)
	return "OTA-ECHO:RCT." .. math.random(1, 999999), true
end

function FACTION:OnSpawn(ply)
	if string.find(ply:GetName(), "RCT") then
		ply:ChatPrint("Congratulations on your whitelist to the overwatch ranks. Please wait while a member of staff assigns you your roles.")
	end
end

function FACTION:OnTransfered(ply)
	local char = ply:GetCharacter()
	
	char:SetName(self:GetDefaultName())
	char:SetModel(self.models[1])
end

function FACTION:OnNameChanged(client, oldValue, value)
	local character = client:GetCharacter()
-- TO:DO Change from ELSEIF to a more efficent switch.
	if (!Schema:IsCombineRank(oldValue, "ECHO") and Schema:IsCombineRank(value, "ECHO")) then
		character:JoinClass(CLASS_ECHO)
		elseif (!Schema:IsCombineRank(oldValue, "XRAY") and Schema:IsCombineRank(value, "XRAY")) then
			character:JoinClass(CLASS_XRAY)
		elseif (!Schema:IsCombineRank(oldValue, "WALLHAMMER") and Schema:IsCombineRank(value, "WALLHAMMER")) then
			character:JoinClass(CLASS_WALLHAM)
		elseif (!Schema:IsCombineRank(oldValue, "RIOT") and Schema:IsCombineRank(value, "RIOT")) then
			character:JoinClass(CLASS_RIOT)
		elseif (!Schema:IsCombineRank(oldValue, "HONOR") and Schema:IsCombineRank(value, "HONOR")) then
			character:JoinClass(CLASS_HONOR)
		elseif (!Schema:IsCombineRank(oldValue, "ORDINAL") and Schema:IsCombineRank(value, "ORDINAL")) then
			character:JoinClass(CLASS_ORDINAL)
	end
end

FACTION_OTA = FACTION.index