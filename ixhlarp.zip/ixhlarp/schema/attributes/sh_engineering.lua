ATTRIBUTE.name = "Engineering Knowledge"
ATTRIBUTE.description = "Your affinity for engineering."
ATTRIBUTE.noStartBonus = true