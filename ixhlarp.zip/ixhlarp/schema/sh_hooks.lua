function Schema:CanPlayerUseBusiness()
	return false
end

function Schema:CanDrive()
	return false
end

function Schema:ScalePlayerDamage(ply, hitGroup, dmginfo)
	if not dmginfo:GetInflictor():IsPlayer() then return end
	if not ply:GetModel():find("combine_heavy") then
    	if (!dmginfo:IsFallDamage() and !dmginfo:IsDamageType(DMG_CRUSH) and dmginfo:IsBulletDamage()) then
    		if (hitGroup == HITGROUP_HEAD) then
    			dmginfo:ScaleDamage(2)
    		elseif (hitGroup == HITGROUP_CHEST or hitGroup == HITGROUP_GENERIC) then
    			dmginfo:ScaleDamage(1.8)
    		elseif (hitGroup == HITGROUP_LEFTARM or hitGroup == HITGROUP_RIGHTARM or hitGroup == HITGROUP_LEFTLEG or hitGroup == HITGROUP_RIGHTLEG or hitGroup == HITGROUP_GEAR) then
    			dmginfo:ScaleDamage(0.8)
    		end
        end
    end
end