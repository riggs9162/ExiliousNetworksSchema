EX_Config = {}
-- ^ do not fucking edit this ^ --

--== Community Configs ==--
EX_Config.Name = "Exilious Networks"
EX_Config.Schema = "Half-Life Alyx Roleplay"
EX_Config.FullName = EX_Config.Name .. ": " .. EX_Config.Schema
EX_Config.DiscordInvite = "discord.gg/TV4hc4FbEG"
EX_Config.ServerIP = "185.38.151.129:27030"



--== Item Configs ==--
EX_Config.ChargerRate = "3" -- Sets how long a player has to wait before using the Armour Charger again.
