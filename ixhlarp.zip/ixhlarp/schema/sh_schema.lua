-- Schema Statistics

Schema.name = "Half-Life Alyx Serious Roleplay"
Schema.description = "We are a Half-Life 2 Serious Roleplay server set in the helix framework."
Schema.community = "Exilious Networks"

Schema.author = "Riggs & Fear"
Schema.developers = "Riggs & Candyexin"

-- Schema Config

Schema.MainColor = Color(0, 160, 255)
Schema.MainColorSelect = Color(40, 200, 255)

Schema.ButtonClick = Sound("ui/buttonclick.wav")
Schema.ButtonHover = Sound("ui/buttonrollover.wav")

Schema.RunFootstepVolume = 70
Schema.FootstepVolume = 40

Schema.HL2Weapons = {
	["weapon_pistol"] = true,
	["weapon_357"] = true,
	["weapon_smg1"] = true,
	["weapon_shotgun"] = true,
	["weapon_stunstick"] = true,
	["weapon_slam"] = true,
	["weapon_bugbait"] = true,
	["weapon_crossbow"] = true,
	["weapon_crowbar"] = true,
	["weapon_frag"] = true,
	["weapon_physcannon"] = true,
	["weapon_ar2"] = true,
	["weapon_rpg"] = true
}
-- Support for IsCombineRank()
function Schema:IsCombineRank(text, rank)
	return string.find(text, "[%D+]"..rank.."[%D+]")
end

-- Include Files

ix.util.Include("cl_schema.lua")
ix.util.Include("sv_schema.lua")

ix.util.Include("cl_hooks.lua")
ix.util.Include("sh_hooks.lua")
ix.util.Include("sv_hooks.lua")

ix.util.Include("sh_anims.lua")
ix.util.Include("sh_voices.lua")

ix.util.IncludeDir("meta")

-- Config & Options

ix.currency.symbol = "T"
ix.currency.singular = "Token"
ix.currency.plural = "Tokens"

ix.option.Add("viewBobing", ix.type.bool, true, {
	category = "appearance"
})

ix.option.Add("viewScale", ix.type.number, 0.2, {
	category = "appearance",
	min = 0.05,
	max = 0.3,
	decimals = 2
})

ix.config.Add("socio_status", 0, "The current status of sociostability.", nil, {
	data = {
		min = 0,
		max = 8
	},
	category = "Miscellaneous"
})

ix.config.Add("waiver_status", 0, "The current status of waivers.", nil, {
	data = {
		min = 0,
		max = 3
	},
	category = "Miscellaneous"
})

ix.config.Add("city_code", 0, "The current status of the city code.", nil, {
	data = {
		min = 0,
		max = 3
	},
	category = "Miscellaneous"
})

-- Commands

ix.command.Add("Discord", {
	description = "Join our Discord Server!",
	OnRun = function(_, client)
		client:SendLua([[gui.OpenURL("https://discord.gg/93wRv3BYSR")]])
	end
})

ix.command.Add("Content", {
	description = "Get our Server's Content Pack.",
	OnRun = function(_, client)
		client:SendLua([[gui.OpenURL("https://steamcommunity.com/workshop/filedetails/?id=2430257024")]])
	end
})

ix.command.Add("StopSound", {
	description = "Stop all sounds.",
	OnRun = function(_, client)
		if client:IsSuperAdmin() then
			client:Notify("You have stopped all sounds.")
			client:ConCommand("stopsound")
		end
	end
})

ix.command.Add("StopSounds", {
	description = "Stop all sounds on all players.",
	OnRun = function(_, client)
		if client:IsSuperAdmin() then
			client:Notify("You have ran stopsound on all players.")
			Schema:StopSounds()
		end
	end
})

ix.command.Add("ClearItems", {
	description = "Clear all Items on the map.",
	OnRun = function(_, client)
		if client:IsSuperAdmin() then
			client:Notify("You have cleared all items on the map.")
			Schema:ClearItems()
		end
	end
})

ix.command.Add("ClearWeapons", {
	description = "Clear all HL2 Weapons on the map and on players.",
	OnRun = function(self, client, target)
		if client:IsSuperAdmin() then
			client:Notify("You have cleared all hl2 weapons on the map and on players.")
			Schema:ClearWeapons()
		end
	end
})

ix.command.Add("Search", {
	description = "Search People who are restrained.",
	OnRun = function(self, client, target)
		local data = {}
			data.start = client:GetShootPos()
			data.endpos = data.start + client:GetAimVector() * 96
			data.filter = client
		local target = util.TraceLine(data).Entity

		if (IsValid(target) and target:IsPlayer() and target:IsRestricted()) then
			if (!client:IsRestricted()) then
				Schema:SearchPlayer(client, target)
			else
				return "@notNow"
			end
		end
	end
})

ix.chat.Register("CommandRadio", {
	CanSay = function(self, speaker, text)
		if not (speaker:IsCombineCommand() or speaker:IsDispatch()) then
			speaker:Notify("Only the High Command Combine can radio stuff!")
			return false
		end
	end,
	OnChatAdd = function(self, speaker, text)
		chat.AddText(Color(255, 150, 0), speaker:Nick().." radios in CmdFreq: <:: "..text.." ::>")
	end,
	CanHear = function(self, speaker, listener)
		if not (listener:IsCombineCommand() or listener:IsDispatch()) then
			return false
		else
			if (listener:IsCombine() or listener:IsDispatch()) and (listener:GetMoveType() != MOVETYPE_NOCLIP) then
				listener:EmitSound("npc/metropolice/vo/off"..math.random(1,4)..".wav", 60)
			end
			return true
		end
	end,
	prefix = {"/CMDRadio", "/CR"},
	description = "Radio something to the commanding units of the combine.",
	indicator = "chatRadioing",
	font = "RadioFont",
	deadCanChat = false
})

ix.chat.Register("DispatchRadio", {
	CanSay = function(self, speaker, text)
		if not (speaker:IsDispatch()) then
			speaker:Notify("Only Dispatch can use this command.")
			return false
		end
	end,
	OnChatAdd = function(self, speaker, text)
		chat.AddText(Color(150, 50, 50), "Dispatch radios in <:: "..text.." ::>")
	end,
	CanHear = function(self, speaker, listener)
		if not (listener:IsCombine() or listener:IsDispatch()) then
			return false
		else
			if (listener:IsCombine() or listener:IsDispatch()) and (listener:GetMoveType() != MOVETYPE_NOCLIP) then
				listener:EmitSound("npc/metropolice/vo/off"..math.random(1,4)..".wav", 60)
			end
			return true
		end
	end,
	prefix = {"/DRadio", "/DR"},
	description = "Dispatch something to the combine.",
	indicator = "chatRadioing",
	font = "RadioFont",
	deadCanChat = false
})

ix.chat.Register("dispatch", {
	CanSay = function(self, speaker, text)
		if not (speaker:IsDispatch()) then
			speaker:Notify("Only Dispatch can use this command.")
			return false
		end
	end,
	OnChatAdd = function(self, speaker, text)
		chat.AddText(Color(30, 120, 130), "Dispatch announces: "..text)
	end,
	CanHear = function(self, speaker, listener)
		return true
	end,
	prefix = {"/dispatch", "/d"},
	description = "Dispatch something to the city.",
	indicator = "chatTyping",
	font = "RadioFont",
	deadCanChat = false
})

ix.chat.Register("AdminChat", {
	CanSay = function(self, speaker, text)
		if not (speaker:IsAdmin()) then
			speaker:Notify("Only Staff Members can use the admin chat, silly.")
			return false
		end
	end,
	OnChatAdd = function(self, speaker, text)
		chat.AddText(Schema.MainColor, "[EX-Staff] ", Schema.MainColorSelect, speaker:SteamName(), color_white, ": "..text)
	end,
	CanHear = function(self, speaker, listener)
		if not (listener:IsAdmin()) then
			return false
		else
			return true
		end
	end,
	prefix = {"/AdminChat", "/AC"},
	description = "Talk with other members of staff.",
	indicator = "chatTyping",
	font = "AdminChatFont",
	deadCanChat = true
})

Schema.CP_RankTable = {
	["UNION"] = {
		["RCT"] = {"models/dpfilms/metropolice/hdpolice.mdl", CLASS_UNION, {"stunstick"}, 10},
		["i9"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"stunstick"}, 10},
		["i8"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick"}, 15},
		["i7"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick"}, 15},
		["i6"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick"}, 15},
		["i5"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick",}, 25},
		["i4"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick",}, 25},
		["i3"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick",}, 25},
		["i2"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick", "smg1"}, 35},
		["i1"] = {"models/dpfilms/metropolice/urban_police.mdl", CLASS_UNION, {"pistol", "stunstick", "smg1"}, 35},
		["SqL"] = {"models/dpfilms/metropolice/urbicetrench.mdl", CLASS_UNION, {"stunstick", "smg1", "pistol"}, 40},
		["OfC"] = {"models/dpfilms/metropolice/urbte_police.mdl", CLASS_UNION, {"stunstick", "smg1", "pistol"}, 40},
		["EpU"] = {"models/dpfilms/metropolice/urbte_police.mdl", CLASS_UNION, {"stunstick", "smg1", "pistol"}, 40},
		["DvL"] = {"models/dpfilms/metropolice/urbice_bt.mdl", CLASS_UNION, {"stunstick", "smg1"}, 40}
	},
	["GRID"] = {
		["RCT"] = {"models/dpfilms/metropolice/hdpolice.mdl", CLASS_GRID, {"stunstick", "ziptie" }, 10},
		["i9"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "ziptie"}, 10},
		["i8"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "ziptie", "pistol"}, 15},
		["i7"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "ziptie", "pistol"}, 15},
		["i6"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "ziptie", "pistol"}, 15},
		["i5"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "ziptie", "pistol"}, 25},
		["i4"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "ziptie", "pistol"}, 25},
		["i3"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "ziptie", "pistol"}, 25},
		["i2"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "shotgun", "ziptie", "pistol"}, 35},
		["i1"] = {"models/dpfilms/metropolice/retrocop.mdl", CLASS_GRID, {"stunstick", "shotgun", "ziptie", "pistol"}, 35},
		["SqL"] = {"models/dpfilms/metropolice/reticetrench.mdl", CLASS_GRID, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["OfC"] = {"models/dpfilms/metropolice/rette_police.mdl", CLASS_GRID, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["EpU"] = {"models/dpfilms/metropolice/rette_police.mdl", CLASS_GRID, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["DvL"] = {"models/dpfilms/metropolice/retice_bt.mdl", CLASS_GRID, {"stunstick", "shotgun", "ziptie", "pistol"}, 40}
	},
	["HELIX"] = {
		["RCT"] = {"models/dpfilms/metropolice/hdpolice.mdl", CLASS_HELIX, {"stunstick", "ziptie"}, 10},
		["i9"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "ziptie"}, 10},
		["i8"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "ziptie", "pistol"}, 15},
		["i7"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "ziptie", "pistol"}, 15},
		["i6"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "ziptie", "pistol"}, 15},
		["i5"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "ziptie", "pistol"}, 25},
		["i4"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "pistol", "ziptie"}, 25},
		["i3"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "pistol", "ziptie"}, 25},
		["i2"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "pistol", "ziptie"}, 35},
		["i1"] = {"models/dpfilms/metropolice/civil_medic.mdl", CLASS_HELIX, {"stunstick", "pistol", "ziptie"}, 35},
		["SqL"] = {"models/dpfilms/metropolice/medicetrench.mdl", CLASS_HELIX, {"stunstick", "smg1", "ziptie", "pistol"}, 40},
		["OfC"] = {"models/dpfilms/metropolice/medte_police.mdl", CLASS_HELIX, {"stunstick", "smg1", "ziptie", "pistol"}, 40},
		["EpU"] = {"models/dpfilms/metropolice/medte_police.mdl", CLASS_HELIX, {"stunstick", "smg1", "ziptie", "pistol"}, 40},
		["DvL"] = {"models/dpfilms/metropolice/medice_bt.mdl", CLASS_HELIX, {"stunstick", "smg1", "ziptie", "pistol"}, 40}
	},
	["JURY"] = {
		["RCT"] = {"models/dpfilms/metropolice/hdpolice.mdl", CLASS_JURY, {"stunstick", "ziptie"}, 10},
		["i9"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "ziptie"}, 15},
		["i8"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "ziptie", "pistol"}, 15},
		["i7"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "ziptie", "pistol"}, 15},
		["i6"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "ziptie", "pistol"}, 25},
		["i5"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "ziptie","pistol"}, 25},
		["i4"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "ziptie", "pistol"}, 25},
		["i3"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "ziptie", "pistol"}, 25},
		["i2"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "shotgun", "ziptie", "pistol"}, 35},
		["i1"] = {"models/dpfilms/metropolice/policetrench.mdl", CLASS_JURY, {"stunstick", "shotgun", "ziptie", "pistol"}, 35},
		["SqL"] = {"models/dpfilms/metropolice/eliicetrench.mdl", CLASS_JURY, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["OfC"] = {"models/dpfilms/metropolice/elite_police.mdl", CLASS_JURY, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["EpU"] = {"models/dpfilms/metropolice/elite_police.mdl", CLASS_JURY, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["DvL"] = {"models/dpfilms/metropolice/police_bt.mdl", CLASS_JURY, {"stunstick", "shotgun", "ziptie", "pistol"}, 40}
	},
	["RAZOR"] = {
		["RCT"] = {"models/dpfilms/metropolice/hdpolice.mdl", CLASS_RAZOR, {"stunstick", "ziptie"}, 10},
		["i9"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "pistol", "ziptie"}, 15},
		["i8"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "pistol", "ziptie"}, 20},
		["i7"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "pistol", "ziptie"}, 25},
		["i6"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "pistol", "ziptie"}, 30},
		["i5"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 35},
		["i4"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 35},
		["i3"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["i2"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["i1"] = {"models/dpfilms/metropolice/hl2beta_police.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["SqL"] = {"models/dpfilms/metropolice/beticetrench.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["OfC"] = {"models/dpfilms/metropolice/bette_police.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["EpU"] = {"models/dpfilms/metropolice/bette_police.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 40},
		["DvL"] = {"models/dpfilms/metropolice/betice_bt.mdl", CLASS_RAZOR, {"stunstick", "shotgun", "ziptie", "pistol"}, 40}
	},
	["MPF"] = {
	   	["CmD"] = {"models/dpfilms/metropolice/blaice_bt.mdl", CLASS_CMD, {"stunstick", "smg1", "zipties", "pistol"}, 50},
		["SeC"] = {"models/dpfilms/metropolice/phoenix_police.mdl", CLASS_SEC, {"stunstick", "smg1", "zipties", "pistol"}, 50}
	}
}

Schema.HudBlackListedWeapons = {
	["ix_hands"] = true,
	["ix_keys"] = true,
	["weapon_physgun"] = true,
	["gmod_tool"] = true,
	["weapon_fists"] = true
}

Schema.SocioStatusCodes = {
    [0] = {"WHITE", Color(255, 255, 255, 255)},
    [1] = {"GREY", Color(100, 100, 100, 255)},
    [2] = {"GREEN", Color(20, 200, 20, 255)},
    [3] = {"BLUE", Color(50, 50, 200, 255)},
    [4] = {"YELLOW", Color(200, 200, 50, 255)},
    [5] = {"ORANGE", Color(255, 100, 0, 255)},
    [6] = {"RED", Color(255, 0, 0, 255)},
    [7] = {"PURPLE", Color(100, 0, 200, 255)},
    [8] = {"BLACK", Color(10, 10, 10, 255)}
}

Schema.WaiverStatus = {
    [0] = {"INACTIVE", Color(20, 200, 20, 255)},
    [1] = {"JUDGEMENT WAIVER", Color(255, 0, 0, 255)},
    [2] = {"PORTAL STORM WAIVER", Color(100, 0, 200, 255)},
    [3] = {"AUTONOMOUS JUDGEMENT WAIVER", Color(200, 200, 50, 255)},
    [4] = {"ORBITAL CANNON", Color(0, 255, 255, 255)}
}

Schema.CityCodes = {
    [0] = {"STABLE - CODE 4", Color(20, 200, 20, 255)},
    [1] = {"CIVIL UNREST - CODE 2", Color(200, 150, 0, 255)},
    [2] = {"UNSTABLE - CODE 3", Color(200, 100, 0, 255)},
    [3] = {"PROTEST - CODE 2", Color(200, 200, 0, 255)},
    [4] = {"RIOT - CODE 3", Color(200, 50, 50, 255)},
    [5] = {"SHIELD - CODE PURPLE", Color(100, 0, 200, 255)},
    [6] = {"SWORD - CODE PURPLE", Color(100, 0, 200, 255)},
    [7] = {"COLLAPSE - CODE RED", Color(255, 0, 0, 255)},
    [8] = {"UPRISING - CODE BLACK", Color(50, 50, 50, 255)}
}

local sociostatuses = {
	["white"] = 0,
	["grey"] = 1,
	["green"] = 2,
	["blue"] = 3,
	["yellow"] = 4,
	["orange"] = 5,
	["red"] = 6,
	["purple"] = 7,
	["black"] = 8
}

-- we don't want people to activate jw and all that shit, it will be enabled by special commands which will make special events, so don't use this. Ty <3
--[[
ix.command.Add("ChangeWaiverStatus", {
	description = "Change the current waiver. (inactive, jw, portalstorm, ajw, orb)",
	syntax = ix.type.string,
	OnRun = function(self, client, status)
		if client:IsAdmin() then
			local waiverstatuses = {
				["inactive"] = 0,
				["jw"] = 1,
				["portalstorm"] = 2,
				["ajw"] = 3,
				["orb"] = 4
			}

			for k, v in pairs(waiverstatuses) do
				if status[1] == k then
					ix.config.Set("waiver_status", v)
				end
			end
		else
			client:Notify("You do not have permission to use this command!")
		end
	end
})
--]]

local citycodes = {
	["stable"] = 0,
	["civilunrest"] = 1,
	["unstable"] = 2,
	["protest"] = 3,
	["riot"] = 4,
	["shield"] = 5,
	["sword"] = 6,
	["collapse"] = 7,
	["uprising"] = 8,
}

ix.command.Add("ChangeSocioStatus", {
	description = "Change the current sociostatus. (white, grey, blue, yellow, orange, red, purple, black)",
	adminOnly = true,
	syntax = ix.type.string,
	OnRun = function(self, client, status)
		if (!client:IsCombine() and !client:IsCombineCommand()) or !client:IsDispatch()  then
			client:Notify("You must be a command unit to use this.")
			return false
		else for code, id in pairs(sociostatuses) do
				if status[1] == code then
					ix.config.Set("socio_status", id)
				end
			end
		end
	end
})

ix.command.Add("ChangeCityCode", {
	description = "Change the city code. (stable, civilunrest, unstable, protest, riot, shield, sword, collapse, uprising)",
	adminOnly = true,
	syntax = ix.type.string,
	OnRun = function(self, client, status)
		if (!client:IsCombine() and !client:IsCombineCommand()) or !client:IsDispatch()  then 
			client:Notify("You must be a command unit to use this.")
		else for code, id in pairs(citycodes) do
			if status[1] == code then
				ix.config.Set("city_code", id)
				end
			end
		end
	end
})

ix.chat.Register("ShadowCompanyRadio", {
	CanSay = function(self, speaker, text)
		if not (speaker:GetModel():find("shadow_company")) then
			speaker:Notify("You are not a Shadow Company Member.")
			return false
		end
	end,
	OnChatAdd = function(self, speaker, text)
		chat.AddText(Color(255, 150, 0), speaker:Nick().." radios in: "..text)
	end,
	CanHear = function(self, speaker, listener)
		if not (listener:GetModel():find("shadow_company")) then
			return false
		else
			return true
		end
	end,
	prefix = {"/SC", "/ShadowCompany"},
	description = "Radio something to the Shadow Company Group.",
	indicator = "chatRadioing",
	font = "RadioFont",
	deadCanChat = false
})

ix.chat.Register("Radio", {
	CanSay = function(self, speaker, text)
		if not (speaker:IsCombine() or speaker:IsDispatch()) then
			speaker:Notify("Only the Combine can radio stuff!")
			return false
		end
	end,
	OnChatAdd = function(self, speaker, text)
		chat.AddText(Color(0, 150, 255), speaker:Nick().." radios in <:: "..text.." ::>")
	end,
	CanHear = function(self, speaker, listener)
		if not ((listener:IsCombine() or listener:IsDispatch()) or (listener:GetModel():find("shadow_company"))) then
			return false
		else
			if listener:IsCombine() or listener:IsDispatch() and (listener:GetMoveType() != MOVETYPE_NOCLIP) then
				listener:EmitSound("npc/metropolice/vo/off"..math.random(1,4)..".wav", 60)
			end
			return true
		end
	end,
	prefix = {"/Radio", "/R"},
	description = "Radio something to the combine.",
	indicator = "chatRadioing",
	font = "RadioFont",
	deadCanChat = false
})