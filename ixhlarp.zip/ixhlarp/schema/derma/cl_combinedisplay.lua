--[[
Made by Scotnay
]]--

local PLUGIN = PLUGIN

local PANEL = {}

surface.CreateFont("NewBudgetLabel", {
	font = "BudgetLabel",
	size = ScreenScale(5.5),
	outline = true,
	shadow = true
})

surface.CreateFont("NewBudgetLabelVisor", {
	font = "BudgetLabel",
	size = ScreenScale(4.5),
	outline = true
})
--[[
local function GetTaglines()
	divisions = {"UNION", "GRID", "HELIX", "JURY", "RAZOR", "CmD", "SeC"}
	return divisions
end

local function GetCPRanks()
	local ranks = {"RCT", "09", "08", "07", "06", "05", "04", "03", "02", "01", "SqL", "OfC", "DvL", "DcO", "CmD", "SeC"}
	return ranks
end

local function GetOTARanks()
	local ranks = {"OWR", "OWT", "OWS", "OWS-2", "OWS-1", "OWE", "OWE-2", "OWE-1", "OW-LT", "OW-CPT", "OWL", "OW-SU", "OW-SU", "OW-SSU", "OW-DC", "OWC"} -- Change These
	return ranks
end

local function GetOLRanks()
	local ranks = {"PLEO", "PCmD"}
	return ranks
end
--]]
local function GetSocioStatus()
	return ix.config.Get("socio_status")
end

local function GetWaiverStatus()
	return ix.config.Get("waiver_status")
end

local function GetCityCode()
	return ix.config.Get("city_code")
end

local SocioColours = {
	WHITE = Color(255, 255, 255),
	GREY = Color(125, 125, 125),
	GREEN = Color(75, 255, 75),
	BLUE = Color(0, 205, 255),
	YELLOW = Color(255, 255, 0),
	ORANGE = Color(255, 100, 0),
	RED = Color(255, 50, 50),
	PURPLE = Color(240, 50, 255),
	BLACK = Color(0, 0, 0)
}

local WaiverColours = {
	INACTIVE = Color(75, 255, 75),
	["JUDGEMENT WAIVER"] = Color(255, 255, 255),
	["PORTAL STORM WAIVER"] = Color(240, 50, 255),
	["AUTONOMOUS JUDGEMENT WAIVER"] = Color(255, 255, 0)
}

local CityCodeColours = {
	["STABLE - CODE 4"] = Color(75, 255, 75),
	["CIVIL UNREST - CODE 2"] = Color(255, 190, 50),
	["UNSTABLE - CODE 3"] = Color(255, 100, 0),
	["PROTEST - CODE 2"] = Color(255, 255, 0),
	["RIOT - CODE 3"] = Color(255, 50, 50),
	["SHIELD - CODE PURPLE"] = Color(120, 0, 255),
	["SWORD - CODE PURPLE"] = Color(120, 0, 255),
	["COLLAPSE - CODE RED"] = Color(255, 0, 0),
	["UPRISING - CODE BLACK"] = Color(0, 0, 0)
}


--local tsin = TimedSin(1, 100, 255, 0)

function PANEL:Init()
	self:SetSize(ScrW(), ScrH())

	ix.gui.combine = self

	self.info = {}
	self.lines = {}
	self.suitBootup = true
	self.objectivePanel = vgui.Create("Panel", self)
	self.datastream = vgui.Create("Panel", self)
	self.suitdiagnostics = vgui.Create("Panel", self)

	local startUpLines = {
		"Booting system parameters...",
		"Restoring suit preferences...",
		"Establishing Dispatch interfacing...",
		"Loading city manifest...",
		"Probing city frequencies...",
		"Restoring suit diagnostics...",
		"Locating biosignal positioning...",
		"Suit diagnostics starting...",
		"Sending diagnotics to dispatch...",
		"Bio-Systems fully functional...",
		"Adjusting Assignments...",
		"Welcome back " .. LocalPlayer():GetName()
	}

	for i, v in ipairs(startUpLines) do
		timer.Simple(i * 2, function()
			self:AddLine(v, Color(255, 255, 255), true)
		end)
	end

	timer.Simple((#startUpLines * 2) + 1 ,function()
		LocalPlayer():EmitSound("npc/scanner/combat_scan5.wav")
	end)

	timer.Simple(#startUpLines * 5, function()
		self.suitBootup = false
	end)

	local panel = self.objectivePanel
	panel:SetSize(ScrW()/5, 0)
	panel:SetPos(10, 10)
	panel:SizeTo(ScrW()/5, 80, 0.7, 3 * 2, 0.4, function()
		LocalPlayer():EmitSound("npc/scanner/combat_scan1.wav")
	end)
	panel.Paint = function(pan, w, h)
		draw.RoundedBox(1, 0, 0, w, h, Color(0, 0, 0, 130))
		surface.SetDrawColor(0, 0, 0)
		surface.DrawOutlinedRect(0, 0, w, h, 2)

		local tsin = TimedSin(0.45, 140, 255, 0)

		local socioColour = SocioColours[GetSocioStatus()]
		local waiverColour = WaiverColours[GetWaiverStatus()]
		local codeColour = CityCodeColours[GetCityCode()]

		if string.match(GetSocioStatus(), "BLACK") then
			socioColour = Color(tsin, tsin, tsin)
		end

		if string.match(GetWaiverStatus(), "BLACK") then
			waiverColour = Color(tsin, tsin, tsin)
		end

		if string.match(GetCityCode(), "BLACK") then
			codeColour = Color(tsin, tsin, tsin)
		end

		draw.SimpleText("<:: Sociostability: " .. Schema.SocioStatusCodes[GetSocioStatus()][1] .. " ::>", "NewBudgetLabel", 5, h/5, Schema.SocioStatusCodes[GetSocioStatus()][2], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("<:: Waiver Status: " .. Schema.WaiverStatus[GetWaiverStatus()][1] .. " ::>", "NewBudgetLabel", 5, h/2, Schema.WaiverStatus[GetWaiverStatus()][2], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
		draw.SimpleText("<:: City Code: " .. Schema.CityCodes[GetCityCode()][1] .. " ::>", "NewBudgetLabel", 5, h/1.25, Schema.CityCodes[GetCityCode()][2], TEXT_ALIGN_LEFT, TEXT_ALIGN_CENTER)
	end

	local datastream = self.datastream
	datastream:SetSize(ScrW()/4, 195)
	datastream:SetPos(ScrW() - ((ScrW() / 4) + 10), 10)
	datastream.Paint = function(pan, w, h)
		local textHeight = draw.GetFontHeight("NewBudgetLabelVisor")
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 130))
		surface.SetDrawColor(0, 0, 0)
		surface.DrawOutlinedRect(0, 0, w, h, 2)

		local y = 0

		for i, v in ipairs(self.lines) do
			if CurTime() > v[3] then table.remove(self.lines, i) end
			if v[4] < v[1]:len() then
				v[4] = v[4] + 1
			end
			draw.SimpleText(v[1]:sub(1, v[4]), "NewBudgetLabelVisor", 5, y, v[2], TEXT_ALIGN_LEFT)
			y = y + textHeight
		end
	end

	local suit = self.suitdiagnostics
	suit:SetSize(ScrW()/5, 0)
	suit:SetPos(10, 100)
	suit:SizeTo(ScrW()/5, 300, 0.7, 6 * 2, 0.4, function()
		LocalPlayer():EmitSound("npc/scanner/combat_scan2.wav")
	end)

	suit.Paint = function(pan, w, h)
		draw.RoundedBox(1, 0, 0, w, h, Color(0, 0, 0, 130))
		surface.SetDrawColor(0, 0, 0)
		surface.DrawOutlinedRect(0, 0, w, h, 2)
		draw.GetFontHeight("NewBudgetLabel")

		if !LocalPlayer():Alive() then return end


		local BiosignalStatus

		if LocalPlayer():Alive() then
			BiosignalStatus = "Active"
		else
			BiosignalStatus = "Inactive"
		end

		local area = LocalPlayer():GetArea() or "<404 UNDOCUMENTED ZONE>"
		local pos = LocalPlayer():GetPos()
		local weapon = LocalPlayer():GetActiveWeapon():GetPrintName()

		local grid1 = math.Round(pos.x/100)
		local grid2 = math.Round(pos.y/100)

		draw.SimpleText("<:: Suit Diagnostics... ::>", "NewBudgetLabel", 5, 0, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Vitals: " .. (LocalPlayer():Health() / LocalPlayer():GetMaxHealth()) * 100 .. "% ::>", "NewBudgetLabel", 5, 25, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Suit Integrity: " .. (LocalPlayer():Armor() / LocalPlayer():GetMaxArmor()) * 100 .. "% ::>", "NewBudgetLabel", 5, 50, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Blood Oxygen Level: " .. math.Round((LocalPlayer():GetNetVar("stm", 100) / 100) * 100) .. "% ::>", "NewBudgetLabel", 5, 75, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Biosignal Status: " .. BiosignalStatus .. " ::>", "NewBudgetLabel", 5, 100, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Biosignal Location: " .. area .. " ::>", "NewBudgetLabel", 5, 125, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Biosignal Grid Position: " .. grid1 .. " | " .. grid2 .. " ::>", "NewBudgetLabel", 5, 150, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Active Weapons: " .. weapon .. " ::>", "NewBudgetLabel", 5, 175, Color(255, 255, 255), TEXT_ALIGN_LEFT)
		draw.SimpleText("<:: Tokens: " .. LocalPlayer():GetCharacter():GetMoney() .. " ::>", "NewBudgetLabel", 5, 200, Color(255, 255, 255), TEXT_ALIGN_LEFT)	
	end
end

function PANEL:Paint(w, h)
	for i, v in pairs(self.info) do
			if IsValid(v) then
			local pos = i:GetBonePosition(i:LookupBone("ValveBiped.Bip01_Head1"))
			local posToScreen = pos:ToScreen()

			local x, y = v:GetPos()
			local panW, panH = v:GetSize()


			if i:IsCombine() or i:IsDispatch() then
				surface.SetDrawColor(0, 110, 230)
			else
				surface.SetDrawColor(255, 100, 0)
			end
			surface.DrawLine(posToScreen.x, posToScreen.y, x, y + panH)
		end
	end
end

function PANEL:AddLine(text, colour, beep, ...)
	if #self.lines > 10 then
		table.remove(self.lines, 1)
	end

	if colour == false or colour == nil then
		colour = Color(255, 255, 255)
	end

	if (text:sub(1, 1) == "@") then
		text = L(text:sub(2), ...)
	end

	self.lines[#self.lines + 1] = {"<:: " .. text .. " ::>", colour, CurTime() + 12, 1}
	if beep then
		LocalPlayer():EmitSound("npc/roller/code2.wav")
	end
end

--[[function PANEL:AddUnit(ply)
	self.info[ply] = vgui.Create("DPanel", self)
	self.info[ply]:SetSize(0, 0)

	self.info[ply].outline = vgui.Create("DSprite", self)
	self.info[ply].outline:SetSize(140, 140)
	self.info[ply].outline:SetColor(Color(0, 110, 230, 100))
	self.info[ply].outline:LerpPositions(1, true)
	self.info[ply].outline:SetMaterial(Material("vgui/hud/xbox_reticle"))

	self.info[ply].outline.Paint = function(pan, w, h)
		--local bone = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
		--local bonePos = bone + Vector(0, 0, 2)
		surface.SetMaterial(pan:GetMaterial())
		if ply:IsCombine() or ply:IsDispatch() then
			surface.SetDrawColor(0, 110, 230)
		else
			surface.SetDrawColor(255, 100, 0)
		end
		surface.DrawTexturedRectRotated(0, 0, w, h, (CurTime() % 360) * 15)

		surface.DrawTexturedRectRotated(0, 0, w/1.3, h/1.3, (-CurTime() % 360) * 30)
	end

	self.info[ply].outline.Think = function(pan)
		local bone = ply:LookupAttachment("eyes")
		local bonePos = ply:GetAttachment(bone).Pos
		local posToScreen = bonePos:ToScreen()
		local distance = bonePos:Distance(LocalPlayer():GetPos())
		if !pan.nextMove then pan.nextMove = CurTime() end -- Doing this to smooth out the movement a little bit
    if pan.nextMove < CurTime() then
      pan:SetPos(posToScreen.x, posToScreen.y)
      pan.nextMove = CurTime() + 0.015
    end
    if !pan.nextSize then pan.nextSize = CurTime() end
    if pan.nextSize < CurTime() then
      pan:SizeTo(175 / (distance / 300), 175 / (distance / 300), 1, 0, 1, function()
        pan.nextSize = CurTime() + 0.35
      end)
    end
	end


	local bone = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
	local ang = EyeAngles()
	local bonePos = bone + ang:Right() * 18.5
	local posToScreen = bonePos:ToScreen()
	self.info[ply]:SetPos(posToScreen.x, posToScreen.y)
	self.info[ply]:LerpPositions(1, true)
	self.info[ply]:MoveToFront()

	self.info[ply]:SizeTo(270, 100, 0.4, 0, 0.4, function() return end)
	self.info[ply].Paint = function(pan, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(0, 0, 0, 220))
		if ply:IsCombine() or ply:IsDispatch() then
			surface.SetDrawColor(0, 110, 230)
		elseif ply:IsRebel() then -- Cool stuff
			surface.SetDrawColor(255, 0, 0)
		else
			surface.SetDrawColor(255, 100, 0)
		end
		surface.DrawOutlinedRect(0, 0, w, h, 2)
		local tag
		local rank = ""

		if ply:Team() == FACTION_CP then
			for i, v in ipairs(GetTaglines()) do
				if string.match(ply:GetName(), v) then
					tag = v
					break
				end
			end

			for i, v in ipairs(GetCPRanks()) do
				if string.match(ply:GetName(), v) then
					rank = v
				end
			end
		elseif ply:Team() == FACTION_OTA then
			for i, v in ipairs(GetTaglines()) do
				if string.match(ply:GetName(), v) then
					tag = v
					break
				end
			end

			for i, v in ipairs(GetOTARanks()) do
				if string.match(ply:GetName(), v) then
					rank = v
				end
			end
		end


		local teamTable = {
			[FACTION_OL] = function(client)
				draw.SimpleText("<:: Evaluation: PROTECT::>", "NewBudgetLabelVisor", 5, 60, Color(0, 90, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: PRIORITY: Immediate ::>", "NewBudgetLabelVisor", 5, 60, Color(111, 0, 255), TEXT_ALIGN_LEFT)
			end,
			[FACTION_CP] = function(client)
				draw.SimpleText("<:: Unit ID: " .. string.match(client:GetName(), "%d%d%d%d") .. " ::>", "NewBudgetLabelVisor", 5, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: Unit PT: " .. "1" .. " ::>", "NewBudgetLabelVisor", 5, 25, Color(255, 255, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: Unit Division: " .. tag .. " ::>", "NewBudgetLabelVisor", 5, 45, Color(255, 255, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: Unit Rank: " .. rank .. " ::>", "NewBudgetLabelVisor", 5, 65, Color(255, 255, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: Evaluation: PROTECT ::>", "NewBudgetLabelVisor", 5, 85, Color(0, 90, 255), TEXT_ALIGN_LEFT)
			end,
			[FACTION_OTA] = function(client)
				if client:Team() == FACTION_OTA and LocalPlayer():Team() != FACTION_OTA then
					draw.SimpleText("<:: <RESTRICTED> ::>", "NewBudgetLabelVisor", 5, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: <RESTRICTED> ::>", "NewBudgetLabelVisor", 5, 25, Color(255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: <RESTRICTED> ::>", "NewBudgetLabelVisor", 5, 45, Color(255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: <RESTRICTED> ::>", "NewBudgetLabelVisor", 5, 65, Color(255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: Evaluation: SACRIFICE ::>", "NewBudgetLabelVisor", 5, 85, Color(TimedSin(.75, 120, 255, 0), TimedSin(.75, 120, 255, 0), TimedSin(.75, 120, 255, 0)), TEXT_ALIGN_LEFT)
				elseif client:Team() == FACTION_OTA and LocalPlayer():Team() == FACTION_OTA then
					draw.SimpleText("<:: Unit ID: " .. string.match(client:GetName(), "%d%d%d%d") .. " ::>", "NewBudgetLabelVisor", 5, 5, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: Unit PT: " .. "1" .. " ::>", "NewBudgetLabelVisor", 5, 25, Color(255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: Unit Division: " .. tag .. " ::>", "NewBudgetLabelVisor", 5, 45, Color(255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: Unit Rank: " .. rank .. " ::>", "NewBudgetLabelVisor", 5, 65, Color(255, 255, 255), TEXT_ALIGN_LEFT)
					draw.SimpleText("<:: Evaluation: PROTECT ::>", "NewBudgetLabelVisor", 5, 85, Color(0, 90, 255), TEXT_ALIGN_LEFT)
				end
			end,
			[FACTION_CITIZEN] = function(client) -- Client is the player we're looking at, replace template with team ENUM
				local CitEval = "<ERROR>"
				if client:Team() == FACTION_CITIZEN then
					local CID = client:GetData("CID")
				end
				draw.SimpleText("<:: CID: " .. CID .. " ::>", "NewBudgetLabelVisor", 5, 10, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: <RESTRICTED DATA> ::>", "NewBudgetLabelVisor", 5, 30, Color(255, 255, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: Vital Status: ".. client:GetHealth() .." ::>", "NewBudgetLabelVisor", 5, 50, Color(255, 255, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("<:: Evaluation: " .. CitEval .. " ::>", "NewBudgetLabelVisor", 5, 70, Color(0, 90, 255), TEXT_ALIGN_LEFT)
			end
		}
		if teamTable[ply:Team()] then
			local suc, res = pcall(teamTable[ply:Team()], ply)
			if !suc then
				draw.SimpleText("Alert! Display is corrupt!", "NewBudgetLabelVisor", 5, 30, Color(200, 50, 50, 255), TEXT_ALIGN_LEFT)
				draw.SimpleText("(Please Contact a Staff Member about this.)", "NewBudgetLabelVisor", 5, 50, Color(200, 50, 50, 255), TEXT_ALIGN_LEFT)
			end
		end

		local tsin = TimedSin(0.2, 70, 140 * 2, 0)

		surface.SetDrawColor(30, 30, 30, 190)
		surface.DrawRect(2, tsin, 266, 2)
	end
	self.info[ply].Think = function(pan)
		if !IsValid(ply) then pan:Remove() return end
		local bone = ply:GetBonePosition(ply:LookupBone("ValveBiped.Bip01_Head1"))
		local bonePos = bone + EyeAngles():Right() * 10 + Vector(0, 0, 8)
		local posToScreen2 = bonePos:ToScreen()
		local distance = bonePos:Distance(LocalPlayer():GetPos())
		pan:SetPos(posToScreen2.x, posToScreen2.y)


		if !LocalPlayer():IsLineOfSightClear(ply) or !posToScreen2.visible then
			pan:Remove()
			self.info[ply].outline:Remove()
			timer.Simple(0.6, function()
				self.info[ply] = nil
			end)
		end

		if distance > 165 then
			pan:SizeTo(0, 0, 0.4, 0, 0.4, function()
				if !LocalPlayer():IsLineOfSightClear(ply) or !posToScreen2.visible then
					pan:Remove()
					self.info[ply].outline:Remove()
					timer.Simple(0.6, function()
					if !IsValid(pan) then return end
						self.info[ply] = nil
					end)
				end
			end)
		end
	end
end--]]

function PANEL:Think()
	if not (LocalPlayer():Alive() and LocalPlayer():IsValid()) then return false end
	if IsValid(ix.gui.menu) or IsValid(ix.gui.characterMenu) then return false end

	if !self.NextMessage then
		self.NextMessage = CurTime()
	end

	local randomMessages = {
		-- Actual Messages
		"Updating data connections...",
		"Looking up main protocols...",
		"Updating Translation Matrix...",
		"Establishing connection with overwatch...",
		"Opening up aura scanners...",
		"Establishing Clockwork protocols...",
		"Looking up active fireteam control centers...",
		"Command uplink established...",
		"Inititaing self-maintenance scan...",
		"Scanning for active biosignals...",
		"Updating cid registry link...",
		"Establishing variables for connection hooks...",
		"Creating socket for incoming connection...",
		"Initializing squad uplink interface...",
		"@sivoe-main: 3fj89323r829j20-",
		"Validating memory replacement integrity...",
		"Visual uplink status code: GREEN...",
		"Refreshing primary database connections...",
		"Creating ID's for internal structs...",
		"Dumping cache data and renewing from external memory...",
		"Updating squad statuses...",
		"Looking up front end codebase changes...",
		"Software status nominal...",
		"Querying database for new recruits... RESPONSE: OK",
		"Establishing connection to long term maintenance procedures...",
		"Looking up CP-5 Main...",
		"Updating railroad activity monitors...",
		"Caching new response protocols...",
		"Calculating the duration of patrol...",
		"Caching internal watch protocols...",
		-- Memes
		"Downloading BeeMovieScript.txt",
		"Praising Scotnay...",
		"elseif elseif elseif elseif... Jesus did Riggs code this?",
		"Ripping scotnays code",
		"Downloading Candy's Nudes"
	}

	if self.NextMessage < CurTime() and self.suitBootup == false then
		self:AddLine(table.Random(randomMessages), Color(255, 255, 255), false)
		self.NextMessage = CurTime() + math.random(15, 45)
	end
end

vgui.Register("ixCombineDisplay", PANEL, "Panel")

if (IsValid(ix.gui.combine)) then
	ix.gui.combine:Remove()
	vgui.Create("ixCombineDisplay")
end