surface.CreateFont("BootFont", {
	font = "BudgetLabel",
	size = 18,
	weight = 0,
})

local PANEL = {}

function PANEL:Init()
	local client = LocalPlayer()
	self:SetPos(ScrW() / 4, ScrH() / 4)
	self:SetSize(0, 0)
	self:SetTitle("")
	self:MakePopup()
	self:ShowCloseButton(false)
	self:SetDraggable(false)
	self:SetSizable(false)
	function self:AddLabel(text, x, y, sound, delay, color)
		timer.Simple(delay or 0, function()
			if not IsValid(self) then return end
			local BootingLabel = vgui.Create("DLabel", self)
			BootingLabel:SetPos(x or 10, y or 10)
			BootingLabel:SetText(text or "NIL")
			BootingLabel:SetFont("BootFont")
			BootingLabel:SetColor(color or Color(230, 180, 0))
			BootingLabel:SizeToContents()
			surface.PlaySound(sound)
		end)
	end
	self:SizeTo(ScrW() / 2, ScrH() / 2, 0.5, 0, 1, function()
		local x, y = self:GetSize()
		surface.PlaySound("buttons/combine_button7.wav")
		self:AddLabel("UniversalUnionBootSystem.exe activating.", 10, 10, "buttons/blip2.wav", 0, Color(0, 0, 200))
		self:AddLabel("Booting System.. Initializing..", 10, 40, "items/suitchargeok1.wav", 1, Color(0, 0, 200))
		self:AddLabel("connecting to local database..", 10, 80, "common/wpn_select.wav", 3)
		self:AddLabel("successfully connected to local database!", 10, 100, "common/wpn_moveselect.wav", 3.8, Color(0, 200, 0))
		self:AddLabel("attempting to connect to local protection teams..", 10, 140, "common/wpn_select.wav", 5.2)
		self:AddLabel("failed.. attempting..", 10, 160, "common/warning.wav", 7, Color(200, 0, 0))
		self:AddLabel("failed.. attempting..", 10, 180, "common/warning.wav", 9, Color(200, 0, 0))
		self:AddLabel("successfully connected to local protection teams!", 10, 200, "common/wpn_moveselect.wav", 12, Color(0, 200, 0))
		self:AddLabel("activating display..", 10, 240, "common/wpn_select.wav", 13)
		timer.Simple(14, function()
			if not IsValid(self) then return end
			local icon = vgui.Create("DModelPanel", self)
			icon:Dock(RIGHT)
			icon:SetSize(400, ScrH() / 2)
			icon:SetModel(client:GetModel())
			icon:SetFOV(50)
			surface.PlaySound("items/suitchargeno1.wav")
		end)
		self:AddLabel(client:Nick(), ScrW() / 2 - 300, 20, "common/wpn_select.wav", 15, team.GetColor(client:Team()))
		self:AddLabel("Vitals: "..client:Health(), ScrW() / 2 - 300, 40, "common/wpn_select.wav", 16, Color(0, 255, 0, 255))
		self:AddLabel("Armor Energy: "..client:Armor(), ScrW() / 2 - 300, 60, "common/wpn_select.wav", 17, Color(50, 50, 255, 255))
		self:AddLabel("successfully activated display!", 10, 260, "common/wpn_moveselect.wav", 18, Color(0, 200, 0))
		self:AddLabel("welcome back unit!", 10, ScrH() / 2 - 40, "buttons/blip2.wav", 20, Color(200, 200, 200))
		timer.Simple(20, function()
			if not IsValid(self) then return end
			self:ShowCloseButton(true)
		end)
		self:AddLabel("closing display..", x / 2 - 40, y / 2 - 20, "common/warning.wav", 24, Color(200, 0, 0))
		timer.Simple(25, function()
			if not IsValid(self) then return end
			surface.PlaySound("buttons/combine_button_locked.wav")
			self:SizeTo(0, 0, 0.5, 0, 1, function() self:Remove() end)
		end)
	end)
end

function PANEL:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, 240))
	surface.SetDrawColor(0, 0, 0, 255)
	surface.DrawOutlinedRect(0, 0, w, h, 2)
end

vgui.Register("ixBootSequence", PANEL, "DFrame")