surface.CreateFont("DataPanel_Title", {
	font = "Graph 35+ pix",
	size = 24,
})

surface.CreateFont("DataPanel_Error", {
	font = "Graph 35+ pix",
	size = 32,
})

local CombineOverlay01 = ix.util.GetMaterial("effects/combine_binocoverlay")
local CombineOverlay02 = ix.util.GetMaterial("dev/dev_prisontvoverlay002")
local CommandButtonSound = "buttons/button9.wav"

local PANEL = {}

function PANEL:Init()
	self:SetTitle("")
	self:SetPos(0, 0)
	self:SetSize(ScrW(), 0)
	self:MakePopup()
	self:ShowCloseButton(false)
	self:SetDraggable(false)
	self:SetSizable(false)
	
	self:SizeTo(ScrW(), ScrH(), 0.5, 0, 1, function() surface.PlaySound("buttons/bell1.wav") end)

	exitbutton = self:Add("DButton")
	exitbutton:SetText("X")
	exitbutton:SetTextColor(Color(61, 116, 171, 255))
	exitbutton:SetFont("DataPanel_Title")
	exitbutton:SetPos(ScrW() - 45, 5)
	exitbutton:SetSize(40, 60)
	exitbutton.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(3, 28, 51, 250))
	end
	exitbutton.DoClick = function()
		surface.PlaySound("buttons/combine_button7.wav")
		self:CustomClose()
	end
	
	timer.Simple(1.5, function()
	
	surface.PlaySound("buttons/blip1.wav")
	
	local w, h = self:GetSize()
	
	mainpanel = self:Add("DPanel")
	mainpanel:SetPos(5, ScrH() - (h/1.5 + 5))
	mainpanel:SetSize(w - 10, h / 1.5)
	mainpanel.Paint = function(self, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(25, 63, 79, 200))
		draw.RoundedBox(0, w / 1.5 - 17, 5, 2, h - 10, Color(255, 255, 255, 200))
	end

	scrollpanel = mainpanel:Add("DScrollPanel")
	scrollpanel:Dock(RIGHT)
	scrollpanel:DockMargin(5, 0, 5, 5)
	scrollpanel:SetSize(ScrW() / 3, 0)
	
	local userselected = false

	userpanel = mainpanel:Add("DScrollPanel")
	userpanel:Dock(FILL)
	userpanel:DockMargin(5, 5, 10, 5)
	userpanel.Paint = function(self, w, h)
		if userselected == false then
			draw.DrawText("PLEASE SELECT USER!", "DataPanel_Error", w / 2, h / 2, Color(200, 50, 50, 255), TEXT_ALIGN_CENTER)
		else
			surface.SetDrawColor(0, 0, 0, 255)
			surface.DrawOutlinedRect(5, 5, 400, 600, 2)
			draw.DrawText("UPDATED 25/09/20ERR", "DataPanel_Title", 200, 620, color_white, TEXT_ALIGN_CENTER)
		end
	end
	
	local w2, h2 = userpanel:GetSize()
	
	local SetText = SetText
	local SizeToContents = SizeToContents
	local SetPos = SetPos
	local SetFont = SetFont
	local surface = surface
	local SetDrawColor = SetDrawColor
	local DrawRect = DrawRect
	local DrawOutlinedRect = DrawOutlinedRect
	local DrawOutlinedRect = DrawOutlinedRect

	usernamelabl = userpanel:Add("DLabel")
	usernamelabl:SetPos(410, 5)
	usernamelabl:SetText("")
	usernamelabl:SetFont("ixMenuButtonFont")
	usernamelabl:SizeToContents()

	usergenderlabl = userpanel:Add("DLabel")
	usergenderlabl:SetPos(410, 40 +5)
	usergenderlabl:SetText("")
	usergenderlabl:SetFont("ixMenuButtonFont")
	usergenderlabl:SizeToContents()

	usercidlabl = userpanel:Add("DLabel")
	usercidlabl:SetPos(410, 140 +5)
	usercidlabl:SetText("")
	usercidlabl:SetFont("ixMenuButtonFont")
	usercidlabl:SizeToContents()

	usertransflabl = userpanel:Add("DLabel")
	usertransflabl:SetPos(410, 180 +5)
	usertransflabl:SetText("")
	usertransflabl:SetFont("ixMenuButtonFont")
	usertransflabl:SizeToContents()

	userstatuslabl = userpanel:Add("DLabel")
	userstatuslabl:SetPos(410, 280 +5)
	userstatuslabl:SetText("")
	userstatuslabl:SetFont("ixMenuButtonFont")
	userstatuslabl:SizeToContents()
	
	usericon = userpanel:Add("DModelPanel")
	usericon:SetPos(7, 7)
	usericon:SetSize(396, 596)
	usericon:SetFOV(50)
	usericon:SetModel("")

	cmdpanel = userpanel:Add("DScrollPanel")
	cmdpanel:SetPos(410, 355)
	cmdpanel:SetSize(600, 250)
	cmdpanel:SetVisible(false)
	cmdpanel.Paint = function(self, w, h)
		surface.SetDrawColor(0, 0, 0, 100)
		surface.DrawRect(0, 0, w, h)
		surface.SetDrawColor(0, 0, 0, 255)
		surface.DrawOutlinedRect(0, 0, w, h, 1)
	end

	actionbutton01 = cmdpanel:Add("DButton")
	actionbutton01:Dock(TOP)
	actionbutton01:DockMargin(5, 5, 5, 0)
	actionbutton01:SetSize(0, 30)
	actionbutton01:SetText("REVOKE CITIZENSHIP")
	actionbutton01:SetTextColor(Color(0, 0, 0))
	actionbutton01:SetFont("ixMenuButtonFontSmall")
	actionbutton01:SetContentAlignment(5)
	actionbutton01.Paint = function(self, w, h)
		if actionbutton01:IsHovered() then
			surface.SetDrawColor(220, 200, 200, 240)
		else
			surface.SetDrawColor(180, 180, 180, 240)
		end
		surface.DrawRect(0, 0, w, h)
	end
	actionbutton01.DoClick = function()
        surface.PlaySound(CommandButtonSound)
		--your job uzi
	end

	actionbutton02 = cmdpanel:Add("DButton")
	actionbutton02:Dock(TOP)
	actionbutton02:DockMargin(5, 5, 5, 0)
	actionbutton02:SetSize(0, 30)
	actionbutton02:SetText("MARK SUSPICIOUS")
	actionbutton02:SetTextColor(Color(0, 0, 0))
	actionbutton02:SetFont("ixMenuButtonFontSmall")
	actionbutton02:SetContentAlignment(5)
	actionbutton02.Paint = function(self, w, h)
		if actionbutton02:IsHovered() then
			surface.SetDrawColor(220, 200, 200, 240)
		else
			surface.SetDrawColor(180, 180, 180, 240)
		end
		surface.DrawRect(0, 0, w, h)
	end
	actionbutton02.DoClick = function()
        surface.PlaySound(CommandButtonSound)
		--your job uzi
	end

	actionbutton03 = cmdpanel:Add("DButton")
	actionbutton03:Dock(TOP)
	actionbutton03:DockMargin(5, 5, 5, 0)
	actionbutton03:SetSize(0, 30)
	actionbutton03:SetText("MARK INFORMANT")
	actionbutton03:SetTextColor(Color(0, 0, 0))
	actionbutton03:SetFont("ixMenuButtonFontSmall")
	actionbutton03:SetContentAlignment(5)
	actionbutton03.Paint = function(self, w, h)
		if actionbutton03:IsHovered() then
			surface.SetDrawColor(60, 220, 60, 240)
		else
			surface.SetDrawColor(40, 180, 40, 240)
		end
		surface.DrawRect(0, 0, w, h)
	end
	actionbutton03.DoClick = function()
        surface.PlaySound(CommandButtonSound)
		--your job uzi
	end

	resetbutton = cmdpanel:Add("DButton")
	resetbutton:Dock(TOP)
	resetbutton:DockMargin(5, 5, 5, 0)
	resetbutton:SetSize(0, 30)
	resetbutton:SetText("! RESET CITIZEN STATUS !")
	resetbutton:SetTextColor(Color(0, 0, 0))
	resetbutton:SetFont("ixMenuButtonFontSmall")
	resetbutton:SetContentAlignment(5)
	resetbutton.Paint = function(self, w, h)
		if resetbutton:IsHovered() then
			surface.SetDrawColor(220, 200, 200, 240)
		else
			surface.SetDrawColor(180, 180, 180, 240)
		end
		surface.DrawRect(0, 0, w, h)
	end
	resetbutton.DoClick = function()
        surface.PlaySound(CommandButtonSound)
		--your job uzi
	end
	
	for k, v in pairs(player.GetAll()) do
		local ply = v
		local char = ply:GetCharacter()
		local usernamebt = char:GetName()
		local username = char:GetName()
		local usermodel = char:GetModel()
		local usercid = string.format("##%s", char:GetData("cid") or "UNKNOWN")
		local usertransf = "69"
		local userstatus = "Informant"
		local usergender = "Male"
		if ply:IsFemale() then
			usergender = "Female"
		end

		namebutton = scrollpanel:Add("ixMenuButton")
		namebutton:Dock(TOP)
		namebutton:DockMargin(0, 8, 0, 0)
		namebutton:SizeToContents()
		namebutton:SetText(usernamebt)
		namebutton.DoClick = function()
			userselected = true
			cmdpanel:SetVisible(true)
			usernamelabl:SetText("Name: "..username)
			usernamelabl:SizeToContents()
			usergenderlabl:SetText("Gender: "..usergender)
			usergenderlabl:SizeToContents()
			usercidlabl:SetText("Citizen ID: "..usercid)
			usercidlabl:SizeToContents()
			usertransflabl:SetText("Transfered From: City "..usertransf)
			usertransflabl:SizeToContents()
			userstatuslabl:SetText("Status: "..userstatus)
			userstatuslabl:SizeToContents()
			usericon:SetModel(usermodel)
			usericon:SetAmbientLight(ix.config.Get("color"))
			function usericon:LayoutEntity(Entity) return end
			local headpos = usericon.Entity:GetBonePosition(usericon.Entity:LookupBone("ValveBiped.Bip01_Head1"))
			usericon:SetLookAt(headpos)
			usericon:SetCamPos(headpos-Vector(-20, 0, 0))
			usericon.Entity:SetEyeTarget(headpos-Vector(-20, 0, 0))
			usericon.Entity:SetBodyGroups(ply:GetBodyGroups())
		end
	end
	
	end)
end

function PANEL:CustomClose()
	self:SizeTo(ScrW(), 0, 0.5, 0, 1, function() self:Remove() end)
end

function PANEL:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(12, 41, 54, 254))
	surface.SetDrawColor(Color(255, 255, 255, 10))
	surface.SetMaterial(CombineOverlay01)
	surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
	draw.RoundedBox(0, 5, 5, w - 55, 60, Color(3, 28, 51, 250))
	draw.DrawText("OVERWATCH DIGITAL ASSISTANT", "DataPanel_Title", ScrW() / 2, 25, Color(61, 116, 171, 255), TEXT_ALIGN_CENTER)
end

vgui.Register("ixDataPanel", PANEL, "DFrame")