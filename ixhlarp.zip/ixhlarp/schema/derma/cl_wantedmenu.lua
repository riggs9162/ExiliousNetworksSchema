local PANEL = {}

function PANEL:Init()
	self:SetPos(ScrW() / 4, ScrH() / 4)
	self:SetSize(0, 0)
	self:MakePopup()
	self:SizeTo(ScrW() / 2, ScrH() / 2, 0.5, 0, 1, function() surface.PlaySound("buttons/combine_button7.wav") end)
	
	local w, h = self:GetSize()

	DList = vgui.Create("DListView", self)
	DList:DockMargin(5, 5, 5, 5)
	DList:Dock(FILL)
	DList.Paint = function(panel, w, h)
		draw.RoundedBox(0, 0, 0, w, h, Color(50, 50, 50, 255))
	end
	DList:AddColumn("Name")
	DList:AddColumn("Gender")
	DList:SetDataHeight(30)
	DList:AddLine("Tyrone Johnson", "Male")
	DList:AddLine("Riggs Mackay", "Male")
	DList:AddLine("Jessica Mackay", "Female")
	DList:AddLine("Mellish Stanley", "Male")
	
	for _, v in ipairs(DList.Columns) do
		v.PaintOver = function(panel, w, h)
			if panel:IsHovered() then
				surface.SetDrawColor(Color(120, 120, 120, 255))
			else
				surface.SetDrawColor(Color(100, 100, 100, 255))
			end
			surface.DrawRect(0, 0, w, h)
			draw.SimpleText(panel.Header:GetText(), "BudgetLabel", w / 2, h / 2, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
			return true
		end
	end

	CloseButton = vgui.Create("DButton", self)
	CloseButton:DockMargin(5, 0, 5, 5)
	CloseButton:Dock(BOTTOM)
	CloseButton:SetText("Finish")
	CloseButton:SetFont("BudgetLabel")
	CloseButton.DoClick = function()
		self:SizeTo(0, 0, 0.5, 0, 1, function() self:Remove() surface.PlaySound("buttons/combine_button2.wav") end)
		surface.PlaySound("buttons/button15.wav")
	end
	CloseButton.Paint = function(panel, w, h)
		if CloseButton:IsHovered() then
			surface.SetDrawColor(Color(120, 120, 120, 255))
		else
			surface.SetDrawColor(Color(100, 100, 100, 255))
		end
		surface.DrawRect(0, 0, w, h)
	end
end

function PANEL:Paint(w, h)
	draw.RoundedBox(0, 0, 0, w, h, Color(20, 20, 20, 200))
end

vgui.Register("ixWantedMenu", PANEL, "Panel")