surface.CreateFont("AdminChatFont", {
	font = "Linux Libertine Slanted",
	size = math.max(ScreenScale(7), 17) * ix.option.Get("chatFontScale", 1),
	weight = 800,
	antialias = true,
	shadow = true,
})

surface.CreateFont("RadioFont", {
	font = "Consolas",
	size = math.max(ScreenScale(7), 17) * ix.option.Get("chatFontScale", 1),
	weight = 500,
	antialias = true,
	shadow = true,
})

function Schema:AddCombineDisplayMessage(text, color, ...)
	if (LocalPlayer():IsCombine() or LocalPlayer():isDispatch()) and IsValid(ix.gui.combine) then
		ix.gui.combine:AddLine(text, color, nil, ...)
	end
end

function Schema:PlaySound(soundfile)
	LocalPlayer():EmitSound(Sound(soundfile))
end

function Schema:LerpColor(time, col, ColorTo)
	for i, v in pairs(col) do
		col[i] = Lerp(time, v, ColorTo[i])
	end
	return col
end