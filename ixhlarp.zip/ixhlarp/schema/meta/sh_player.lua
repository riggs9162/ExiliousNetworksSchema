local PLAYER = FindMetaTable("Player")

function PLAYER:IsCombine()
	return self:Team() == FACTION_CP or
	self:Team() == FACTION_OTA or
	self:Team() == FACTION_OL or
	self:Team() == FACTION_DA
end

function PLAYER:IsDispatch()
	return self:Team() == FACTION_DISP
end

function PLAYER:IsCombineCommand()
	local char = self:GetCharacter()
	return self:Team() == FACTION_OL or 
	char:GetClass() == CLASS_SEC or 
	char:GetClass() == CLASS_CMD
end

function PLAYER:CleanInventory()
	if self:IsPlayer() and not self:IsBot() then
		local char = self:GetCharacter()
		local items = char:GetInventory():GetItems()
		for _, v in pairs(items) do
			v:Remove()
		end
	end
end