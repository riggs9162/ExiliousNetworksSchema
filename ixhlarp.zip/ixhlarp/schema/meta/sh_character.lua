local CHAR = ix.meta.character

function CHAR:IsCombine()
	return self:GetFaction() == FACTION_CP or self:GetFaction() == FACTION_OTA
end
function CHAR:IsDispatch()
	return self:GetFaction() == FACTION_DISP
end
function CHAR:IsCombineCommand()
	return self:GetFaction() == FACTION_OL
end
function CHAR:HasMoney(amount)
	if (amount < 0) then
		print("Negative Money Check Received.")
	end

	return self:GetMoney() >= amount
end