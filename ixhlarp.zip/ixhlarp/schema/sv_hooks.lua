--[[
function Schema:LoadData()
	self:LoadRationDispensers()
	self:LoadVendingMachines()
	self:LoadCombineLocks()
	self:LoadForceFields()

	--This is a function used for something coming in a later update <3
	--Schema.CombineObjectives = ix.data.Get("combineObjectives", {}, false, true)
end

function Schema:SaveData()
	self:SaveRationDispensers()
	self:SaveVendingMachines()
	self:SaveCombineLocks()
	self:SaveForceFields()
end
]]--
function Schema:CharacterLoaded(char)
    local ply = char:GetPlayer()
	if ply:GetModel():find("combine_heavy") then
		ply:SetModelScale(1.1)
	else
		ply:SetModelScale(1)
	end
end

function Schema:EntityTakeDamage(ent, dmg)
	local ply = dmg:GetAttacker()

	if (ent.nextBreach or 0) > CurTime() then return end
	if ent:IsPlayer() and (dmg:GetAttacker():IsPlayer() or dmg:GetAttacker():IsNPC()) then
		ent:SetVelocity(ent:GetAimVector() * - dmg:GetDamage())
	end
	if ent:IsDoor() and ply:IsPlayer() then
	    if ply:GetActiveWeapon():GetClass() == "weapon_shotgun" then
    		if dmg:IsBulletDamage() then
    			ent.oldSpeed = ent.oldSpeed or ent:GetKeyValues().speed or 100
    
    			local name = ply:UniqueID() .. CurTime()
    			ply:SetName(name)
    
    			ent:Fire("setspeed", ent.oldSpeed * 4)
    			ent:Fire("unlock")
    			ent:Fire("openawayfrom", name)
    			ent:EmitSound("physics/wood/wood_plank_break" .. math.random(1, 4) .. ".wav", 100, 120)
    
    			ent.nextBreach = CurTime() + 2
    
    			timer.Simple(0.4, function()
    				if IsValid(ent) then
    					ent:Fire("lock")
    				end
    			end)
    
    			timer.Simple(10, function()
    				if IsValid(ent) then
    					ent:Fire("unlock")
    					ent:Fire("setspeed", ent.oldSpeed or 100)
    				end
    			end)
        	end
    	end
	end
end

function Schema:PlayerSpray()
    return true
end

function Schema:PlayerSwitchFlashlight(client, enabled)
	if (client:IsCombine() or client:IsDispatch()) then
		return true
	end
end

function Schema:GetPlayerDeathSound(ply)
	if ply:IsCombine() then
		return "NPC_MetroPolice.Die"
	end
end

function Schema:GetPlayerPainSound(ply)
	if ply:IsCombine() then
		return "NPC_MetroPolice.Pain"
	end
end

function Schema:PostPlayerLoadout(client)
	if (client:IsCombine()) then
		local factionTable = ix.faction.Get(client:Team())

		if (factionTable.OnNameChanged) then
			factionTable:OnNameChanged(client, "", client:GetCharacter():GetName())
		end
	end
end

function Schema:CharacterVarChanged(character, key, oldValue, value)
	local client = character:GetPlayer()
	if (key == "name") then
		local factionTable = ix.faction.Get(client:Team())

		if (factionTable.OnNameChanged) then
			factionTable:OnNameChanged(client, oldValue, value)
		end
	end
end

function Schema:PlayerDeath(ply, inflictor, attacker)
	ply:SetRestricted(false)
	if (ply:IsCombine()) then
		local deatharea = ply:GetArea() or "unknown location"

		self:AddCombineDisplayMessage("@cLostBiosignal")
		self:AddCombineDisplayMessage("@cLostBiosignalLocation", Color(255, 0, 0, 255), deatharea)
		
		local RandomChance = math.random(1,2)

		local sounds = {"npc/overwatch/radiovoice/on1.wav", "npc/overwatch/radiovoice/lostbiosignalforunit.wav"}
		if (RandomChance == 2) then
			sounds[#sounds + 1] = "npc/overwatch/radiovoice/remainingunitscontain.wav"
		else
			sounds[#sounds + 1] = "npc/overwatch/radiovoice/reinforcementteamscode3.wav"
		end
		sounds[#sounds + 1] = "npc/overwatch/radiovoice/off4.wav"

		for k, v in ipairs(player.GetAll()) do
			if (v:IsCombine()) then
				ix.util.EmitQueuedSounds(v, sounds, 2, nil, 60)
			end
		end
	end
end

function Schema:PlayerSwitchWeapon(ply, oldWeapon, newWeapon)
	if ply:GetMoveType() == MOVETYPE_NOCLIP then return end
	if not ply:GetCharacter() then return end
	ply:ForceSequence("smgdraw", nil, 1, true)
	ply:EmitSound("npc/zombie/foot_slide"..math.random(1,3)..".wav")
	ply:ViewPunch(Angle(1, math.random(-1,1), 1))
end

function Schema:PlayerInteractItem(ply, action, item)
	if ply:GetMoveType() == MOVETYPE_NOCLIP then return end
	if not ply:GetCharacter() then return end
	if (action == "take") or (action == "drop") then
		ply:EmitSound("npc/zombie/foot_slide"..math.random(1,3)..".wav")
		ply:ViewPunch(Angle(1, 1, 1))
		ply:ForceSequence("pickup", nil, 1, true)
	end
end

function Schema:PlayerFootstep(ply)
	local WalkSounds = {
		"exiliousnetworks/weapons/movement/weapon_movement_walk1.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_walk2.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_walk3.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_walk4.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_walk5.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_walk6.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_walk8.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_walk9.wav"
	}
	local RunSounds = {
		"exiliousnetworks/weapons/movement/weapon_movement_sprint1.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_sprint2.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_sprint3.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_sprint4.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_sprint5.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_sprint6.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_sprint8.wav",
		"exiliousnetworks/weapons/movement/weapon_movement_sprint9.wav"
	}
	local RunSoundsGeneric = {
		"exiliousnetworks/weapons/movement/weapon_movement1.wav",
		"exiliousnetworks/weapons/movement/weapon_movement2.wav",
		"exiliousnetworks/weapons/movement/weapon_movement3.wav",
		"exiliousnetworks/weapons/movement/weapon_movement4.wav",
		"exiliousnetworks/weapons/movement/weapon_movement5.wav",
		"exiliousnetworks/weapons/movement/weapon_movement6.wav"
	}
	local ChargerSounds = {
		"exiliousnetworks/combine/footsteps/charger/step01.wav",
		"exiliousnetworks/combine/footsteps/charger/step02.wav",
		"exiliousnetworks/combine/footsteps/charger/step03.wav",
		"exiliousnetworks/combine/footsteps/charger/step04.wav",
		"exiliousnetworks/combine/footsteps/charger/step05.wav",
		"exiliousnetworks/combine/footsteps/charger/step06.wav",
		"exiliousnetworks/combine/footsteps/charger/step07.wav",
		"exiliousnetworks/combine/footsteps/charger/step08.wav",
		"exiliousnetworks/combine/footsteps/charger/step09.wav"
	}
	if (ply:IsCombine()) then
		if ply:IsSprinting() then
			ply:EmitSound(table.Random(RunSounds), 70)
		else
			ply:EmitSound(table.Random(WalkSounds), 50)
		end
	else
		if ply:IsSprinting() then
			ply:EmitSound(table.Random(RunSoundsGeneric), 70)
		end
	end
	
	if ply:IsCombine() then
		if ply:GetModel():find("combine_heavy") then
			ply:EmitSound(table.Random(ChargerSounds), 50, math.random(95,105), 50)
		end
	end
	
	return true
end

function Schema:PlayerMessageSend(speaker, chatType, text, anonymous, receivers, rawText)
	if (chatType == "ic" or chatType == "w" or chatType == "y" or chatType == "Radio" or chatType == "dispatch") then
		local class = self.voices.GetClass(speaker)

		for k, v in ipairs(class) do
			local info = self.voices.Get(v, rawText)

			if (info) then
				local volume = 80

				if (chatType == "w") then
					volume = 50
				elseif (chatType == "y") then
					volume = 150
				end

				if (info.sound) then
					if (info.global) then
						netstream.Start(nil, "PlaySound", info.sound)
					else
						local sounds = {info.sound}

						if (speaker:IsCombine()) then
							speaker.bTypingBeep = nil
							sounds[#sounds + 1] = "NPC_MetroPolice.Radio.Off"
						end

						ix.util.EmitQueuedSounds(speaker, sounds, nil, nil, volume)
					end
				end

				if (speaker:IsCombine()) then
					return string.format("<:: %s ::>", info.text)
				else
					return info.text
				end
			end
		end

		if (speaker:IsCombine()) then
			return string.format("<:: %s ::>", text)
		end
	end
end

function Schema:PlayerTick(ply)
	if not ((PlayerTick_FUCKOFF or 0) > CurTime()) then
		ply:StopSound("ambient/levels/citadel/citadel_ambient_scream_loop1.wav")
		ply:StopSound("ambient/levels/citadel/citadel_ambient_voices1.wav")
		for k, v in pairs(player.GetAll()) do
			v:StopSound("ambient/levels/citadel/citadel_ambient_scream_loop1.wav")
			v:StopSound("ambient/levels/citadel/citadel_ambient_voices1.wav")
		end
		PlayerTick_FUCKOFF = CurTime() + 10
	end
end

function Schema:EntityFireBullets(ent, bullet)
	if ent:IsPlayer() then
		local ply = ent
		--ply:ViewPunch(Angle(1, math.random(2,-2), 0))
		if ply:GetActiveWeapon():GetClass() == "weapon_shotgun" then
			ply:SetVelocity(ply:GetAimVector() * - 100)
		else
			ply:SetVelocity(ply:GetAimVector() * - 20)
		end
		if ply:IsSprinting() then
			--ply:ViewPunch(Angle(1, math.random(1,-1), 0))
		end
	end
end

function Schema:PlayerUse(ply, entity)
	if ((ply:IsCombine() or ply:IsDispatch()) and entity:IsDoor() and IsValid(entity.ixLock) and ply:KeyDown(IN_SPEED)) then
		entity.ixLock:Toggle(ply)
		return false
	end

	if (!ply:IsRestricted() and entity:IsPlayer() and entity:IsRestricted() and !entity:GetNetVar("untying")) then
		entity:SetAction("@beingUntied", 5)
		entity:SetNetVar("untying", true)

		ply:SetAction("@unTying", 5)

		ply:DoStaredAction(entity, function()
			entity:SetRestricted(false)
			entity:SetNetVar("untying")
		end, 5, function()
			if (IsValid(entity)) then
				entity:SetNetVar("untying")
				entity:SetAction()
			end

			if (IsValid(ply)) then
				ply:SetAction()
			end
		end)
	end
	
	local vp = 1
	local cleantime = math.random(10,20)
	
	if not ((PlayerUse_CoolDown or 0) > CurTime()) then
		if (entity:GetNWBool("IsDeadBody", false) == true) then
			timer.Create("DisposingSound", 1, 0, function()
				if not IsValid(entity) then return end
				entity:EmitSound("physics/body/body_medium_impact_soft"..math.random(1,7)..".wav")
				ply:ViewPunch(Angle(math.random(-vp,vp), math.random(-vp,vp), math.random(-vp,vp)))
			end)
			entity:EmitSound("physics/body/body_medium_scrape_smooth_loop1.wav", 60, 80, 80)
			ply:SetAction("Disposing body...", cleantime)
			ply:DoStaredAction(entity, function()
				entity:EmitSound("physics/body/body_medium_impact_soft"..math.random(1,7)..".wav")
				entity:StopSound("physics/body/body_medium_scrape_smooth_loop1.wav")
				entity:Remove()
			end, cleantime, function()
				timer.Destroy("DisposingSound")
				entity:StopSound("physics/body/body_medium_scrape_smooth_loop1.wav")
				ply:SetAction()
			end)
		end
		PlayerUse_CoolDown = CurTime() + 1
	end
	
	return true
end

function Schema:CanPlayerCreateCharacter(ply, payload)
	if (ply:IsRestricted()) then
		return false, "notNow"
	end
end

function Schema:CanPlayerUseCharacter(ply, char)
	if (ply:IsRestricted()) then
		return false, "notNow"
	end
end

function Schema:PlayerUseDoor(ply, door)
	if (ply:IsCombine() or ply:IsDispatch()) then
		if (!door:HasSpawnFlags(256) and !door:HasSpawnFlags(1024)) then
			door:Fire("open")
		end
	end
end

function Schema:PlayerSpray(ply)
	return false
end

netstream.Hook("PlayerChatTextChanged", function(ply, key)
	if (ply:IsCombine() and !ply.bTypingBeep and (key == "ic" or key == "y" or key == "w" or key == "Radio")) then
		ply:EmitSound("NPC_MetroPolice.Radio.On")
		ply.bTypingBeep = true
	end
end)

netstream.Hook("PlayerFinishChat", function(ply)
	if (ply:IsCombine() and ply.bTypingBeep) then
		ply:EmitSound("NPC_MetroPolice.Radio.Off")
		ply.bTypingBeep = nil
	end
end)

concommand.Add("hl2rp_commands_stopsoundall", function(ply)
	if ply:IsSuperAdmin() then
		for _, v in pairs(player.GetAll()) do
			v:ConCommand("stopsound")
		end
	end
end)

--[[---------------------------------------------------------------------------
	Sequences : Shake
---------------------------------------------------------------------------]]--

concommand.Add("hl2rp_event_sequences_shake_1", function(ply)
	if ply:IsSuperAdmin() then
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ambient/atmosphere/hole_hit"..math.random(1,5)..".wav")
		for _, ply in pairs(player.GetAll()) do
			util.ScreenShake( ply:GetPos(), 5, 5, 1, 5000 )
		end
	end
end)

concommand.Add("hl2rp_event_sequences_shake_2", function(ply)
	if ply:IsSuperAdmin() then
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ambient/atmosphere/hole_hit"..math.random(1,5)..".wav")
		for _, ply in pairs(player.GetAll()) do
			util.ScreenShake( ply:GetPos(), 5, 5, 2, 5000 )
		end
	end
end)

concommand.Add("hl2rp_event_sequences_shake_3", function(ply)
	if ply:IsSuperAdmin() then
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ambient/atmosphere/hole_hit"..math.random(1,5)..".wav")
		for _, ply in pairs(player.GetAll()) do
			util.ScreenShake( ply:GetPos(), 5, 5, 3, 5000 )
		end
	end
end)

concommand.Add("hl2rp_event_sequences_shake_4", function(ply)
	if ply:IsSuperAdmin() then
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ambient/atmosphere/hole_hit"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ambient/atmosphere/terrain_rumble1.wav")
		for _, ply in pairs(player.GetAll()) do
			util.ScreenShake( ply:GetPos(), 5, 5, 4, 5000 )
		end
	end
end)

concommand.Add("hl2rp_event_sequences_shake_5", function(ply)
	if ply:IsSuperAdmin() then
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ambient/atmosphere/hole_hit"..math.random(1,5)..".wav")
		RunConsoleCommand("ulx", "playsound", "ambient/atmosphere/terrain_rumble1.wav")
		for _, ply in pairs(player.GetAll()) do
			util.ScreenShake( ply:GetPos(), 5, 5, 5, 5000 )
		end
	end
end)

--[[---------------------------------------------------------------------------
	Judgement Waiver
---------------------------------------------------------------------------]]--

concommand.Add("hl2rp_event_jw_start", function(ply)
	if ply:IsSuperAdmin() then
		for _, v in pairs(player.GetAll()) do util.ScreenShake(v:GetPos(), 5, 5, 4, 100) end
		RunConsoleCommand("ulx", "playsound", "ambient/alarms/manhack_alert_pass1.wav")
		RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
		RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
		timer.Simple(1, function()
			RunConsoleCommand("ulx", "playsound", "ambient/alarms/city_siren_loop2.wav")
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
		end)
		timer.Simple(2, function()
			for _, v in pairs(player.GetAll()) do util.ScreenShake(v:GetPos(), 5, 5, 6, 100) end
			RunConsoleCommand("ulx", "playsound", "ambient/machines/wall_move1.wav")
		end)
		timer.Simple(5, function()
			for _, v in pairs(player.GetAll()) do util.ScreenShake(v:GetPos(), 5, 5, 10, 500) end
			RunConsoleCommand("ulx", "playsound", "ambient/machines/wall_crash1.wav")
			RunConsoleCommand("ulx", "playsound", "ambient/levels/streetwar/marching_distant2.wav")
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/alarms/jw/announcer.wav")
			ix.config.Set("waiver_status", 1)
		end)
		timer.Simple(9, function()
			for _, v in pairs(player.GetAll()) do util.ScreenShake(v:GetPos(), 5, 5, 3, 100) end
			RunConsoleCommand("ulx", "playsound", "ambient/materials/metal_big_impact_scrape1.wav")
		end)
		timer.Simple(10, function()
			for _, v in pairs(player.GetAll()) do v:StopSound("ambient/alarms/city_siren_loop2.wav") end
			RunConsoleCommand("ulx", "playsound", "ambient/levels/streetwar/marching_distant2.wav")
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/city_chant1.wav")
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/alarms/jw/klaxon.wav")
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/alarms/jw/klaxon.wav")
			RunConsoleCommand("hl2rp_event_citybattle_start")
			timer.Create("ixJudgementWaiverAlarm", 30, 0, function()
				RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/alarms/jw/klaxon.wav")
				RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/alarms/jw/klaxon.wav")
				for _, v in pairs(player.GetAll()) do
					util.ScreenShake(v:GetPos(), 5, 5, 5, 100)
				end
			end)
			timer.Create("ixJudgementWaiverReminder", 300, 0, function()
				RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/alarms/jw/announcer.wav")
			end)
		end)
		timer.Simple(14, function()
			RunConsoleCommand("ulx", "playsound", "ambient/levels/streetwar/marching_distant2.wav")
		end)
	else
		ply:Notify("You cannot start an Judgement Waiver!")
	end
end)

concommand.Add("hl2rp_event_jw_stop_silent", function(ply)
	if ply:IsSuperAdmin() then
		ix.config.Set("waiver_status", 0)
		timer.Destroy("ixJudgementWaiverAlarm")
		timer.Destroy("ixJudgementWaiverReminder")
		RunConsoleCommand("hl2rp_event_citybattle_stop")
	else
		ply:Notify("You cannot stop an Judgement Waiver!")
	end
end)

concommand.Add("hl2rp_event_jw_stop", function(ply)
	if ply:IsSuperAdmin() then
		for _, v in pairs(player.GetAll()) do util.ScreenShake(v:GetPos(), 5, 5, 3, 250) end
		RunConsoleCommand("ulx", "playsound", "ambient/materials/metal_big_impact_scrape1.wav")
		timer.Destroy("ixJudgementWaiverAlarm")
		timer.Destroy("ixJudgementWaiverReminder")
		RunConsoleCommand("ulx", "playsound", "ambient/alarms/scanner_alert_pass1.wav")
		RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
		RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
		timer.Simple(0.5, function()
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
		end)
		timer.Simple(1, function()
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
			RunConsoleCommand("ulx", "playsound", "doors/door_metal_large_chamber_close1.wav")
		end)
		timer.Simple(2, function()
			for _, v in pairs(player.GetAll()) do util.ScreenShake(v:GetPos(), 5, 5, 6, 100) end
			RunConsoleCommand("ulx", "playsound", "ambient/machines/wall_move1.wav")
		end)
		timer.Simple(4, function()
			RunConsoleCommand("ulx", "playsound", "ambient/machines/wall_move2.wav")
			RunConsoleCommand("ulx", "playsound", "ambient/levels/streetwar/marching_distant2.wav")
			RunConsoleCommand("hl2rp_event_citybattle_stop")
			ix.config.Set("waiver_status", 0)
		end)
		timer.Simple(10, function()
			for _, v in pairs(player.GetAll()) do util.ScreenShake(v:GetPos(), 5, 5, 10, 500) end
			RunConsoleCommand("ulx", "playsound", "ambient/machines/wall_crash1.wav")
			RunConsoleCommand("ulx", "playsound", "ambient/levels/streetwar/marching_distant2.wav")
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/city_chant1.wav")
		end)
		timer.Simple(15, function()
			RunConsoleCommand("ulx", "playsound", "npc/overwatch/cityvoice/f_innactionisconspiracy_spkr.wav")
			RunConsoleCommand("ulx", "playsound", "ambient/levels/streetwar/marching_distant1.wav")
		end)
	else
		ply:Notify("You cannot stop an Judgement Waiver!")
	end
end)

--[[---------------------------------------------------------------------------
	City Battle
---------------------------------------------------------------------------]]--

concommand.Add("hl2rp_event_citybattle_start", function(ply)
	local SpecialGunFire = { -- we want those math.randoms to work.
		"ExiliousNetworks/event/battle/heli_distant1.wav",
		"ExiliousNetworks/event/battle/heli_distant1.wav",
		"ExiliousNetworks/event/battle/gunship_distant1.wav",
		"ExiliousNetworks/event/battle/gunship_distant1.wav",
		"ExiliousNetworks/event/battle/strider_distant"..math.random(1,3)..".wav",
		"ExiliousNetworks/event/battle/strider_distant"..math.random(1,3)..".wav",
		"ExiliousNetworks/event/battle/city_riot1.wav",
		"ExiliousNetworks/event/battle/city_riot1.wav",
		"ExiliousNetworks/event/dispatch/overwatch/missionfailurereminder.wav",
		"ExiliousNetworks/event/explosions/exp"..math.random(1,11)..".wav",
		"ExiliousNetworks/event/explosions/exp"..math.random(1,11)..".wav",
		"ExiliousNetworks/event/explosions/exp"..math.random(1,11)..".wav",
		"ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav",
		"ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav",
		"ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav"
	}
	if ply:IsSuperAdmin() then
		timer.Create("hl2rpCityBattle", 5, 0, function()
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/city_battle"..math.random(1,19)..".wav")
		end)
		timer.Create("hl2rpCityBattle_GunFire", 7, 0, function()
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/distant_battle_gunfire0"..math.random(1,7)..".wav")
		end)
		timer.Create("hl2rpCityBattle_Special", 11, 0, function()
			RunConsoleCommand("ulx", "playsound", table.Random(SpecialGunFire))
		end)
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/battle_loop1.wav")
		for _, v in pairs(player.GetAll()) do
			timer.Create("hl2rpCityBattle_Shake", 30, 0, function()
				util.ScreenShake(v:GetPos(), 5, 5, 2, 100)
			end)
		end
	else
		ply:Notify("You cannot start an Event!")
	end
end)

concommand.Add("hl2rp_event_citybattle_stop", function(ply)
	if ply:IsSuperAdmin() then
		timer.Destroy("hl2rpCityBattle")
		timer.Destroy("hl2rpCityBattle_GunFire")
		timer.Destroy("hl2rpCityBattle_Special")
		timer.Destroy("hl2rpCityBattle_Shake_Sound")
		for _, v in pairs(player.GetAll()) do
			v:StopSound("ExiliousNetworks/event/battle/battle_loop1.wav")
			timer.Destroy("hl2rpCityBattle_Shake")
		end
	else
		ply:Notify("You cannot stop an Event!")
	end
end)

--[[---------------------------------------------------------------------------
	City War
---------------------------------------------------------------------------]]--

concommand.Add("hl2rp_event_citywar_start", function(ply)
	local SpecialGunFire = {
		"ExiliousNetworks/event/battle/distant_battle_citizen01.wav",
		"ExiliousNetworks/event/battle/distant_battle_dropship0"..math.random(1,3)..".wav",
		"ExiliousNetworks/event/battle/distant_battle_hunter01.wav",
		"ExiliousNetworks/event/battle/distant_battle_hunter02.wav",
		"ExiliousNetworks/event/battle/distant_battle_shotgun01.wav",
		"ExiliousNetworks/event/battle/distant_battle_soldier01.wav",
		"ExiliousNetworks/event/battle/heli_distant1.wav",
		"ExiliousNetworks/event/battle/gunship_distant1.wav",
		"ExiliousNetworks/event/battle/strider_distant"..math.random(1,3)..".wav",
		"ExiliousNetworks/event/battle/city_riot2.wav",
		"ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav",
		"ExiliousNetworks/event/overhead/helicopter0"..math.random(1,5)..".wav",
		"ExiliousNetworks/event/dispatch/overwatch/missionfailurereminder.wav",
		"ExiliousNetworks/event/dispatch/overwatch/augmentationinbound.wav",
		"ExiliousNetworks/event/dispatch/overwatch/augmentationdeployed.wav",
		"ExiliousNetworks/event/dispatch/overwatch/sterilizersinbound.wav",
		"ExiliousNetworks/event/dispatch/overwatch/over_arbeit.wav",
		"ExiliousNetworks/event/battle/battle_loop2.wav",
		"ExiliousNetworks/event/explosions/exp"..math.random(1,11)..".wav",
		"ExiliousNetworks/event/radio/radiorebel_lostcontact.wav"
	}
	if ply:IsSuperAdmin() then
		timer.Create("hl2rpCityBattle", 6, 0, function()
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/city_battle"..math.random(1,19)..".wav")
		end)
		timer.Create("hl2rpCityBattle_GunFire", 12, 0, function()
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/distant_battle_gunfire0"..math.random(1,7)..".wav")
		end)
		timer.Create("hl2rpCityBattle_Special", 18, 0, function()
			RunConsoleCommand("ulx", "playsound", table.Random(SpecialGunFire))
		end)
		timer.Create("hl2rpCityBattle_Shake_Sound", 30, 0, function()
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
			RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/building_rubble"..math.random(1,5)..".wav")
		end)
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/battle_loop3.wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/shanty_battle.wav")
		RunConsoleCommand("ulx", "playsound", "ExiliousNetworks/event/battle/eli_battle.wav")
		for _, v in pairs(player.GetAll()) do
			timer.Create("hl2rpCityBattle_Shake", 30, 0, function()
				util.ScreenShake(v:GetPos(), 5, 5, 5, 100)
			end)
		end
	else
		ply:Notify("You cannot start an Event!")
	end
end)

concommand.Add("hl2rp_event_citywar_stop", function(ply)
	if ply:IsSuperAdmin() then
		timer.Destroy("hl2rpCityBattle")
		timer.Destroy("hl2rpCityBattle_GunFire")
		timer.Destroy("hl2rpCityBattle_Special")
		timer.Destroy("hl2rpCityBattle_Shake_Sound")
		for _, v in pairs(player.GetAll()) do
			v:StopSound("ExiliousNetworks/event/battle/battle_loop3.wav")
			v:StopSound("ExiliousNetworks/event/battle/shanty_battle.wav")
			v:StopSound("ExiliousNetworks/event/battle/eli_battle.wav")
			timer.Destroy("hl2rpCityBattle_Shake")
		end
	else
		ply:Notify("You cannot stop an Event!")
	end
end)