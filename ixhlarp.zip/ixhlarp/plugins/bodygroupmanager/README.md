# Bodygroup Manager

## Installation
 - Download the folder as a .zip
 - Place inside of your schema/plugins folder

## Preview
 ![Example](https://i.imgur.com/6bqX51s.png)

## Support
 - Support for this plugin can be found here: https://discord.gg/mntpDMU