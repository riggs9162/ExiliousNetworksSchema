
LANGUAGE = {
	["CraftMissingFlag"] = "You are missing the %s flag.",
	["CraftMissingTool"] = "You are missing a %s.",
	["CraftMissingItem"] = "You are missing: %s.",
	["CraftSuccess"] = "You have successfully crafted %s.",

	["CraftTools"] = "TOOLS",
	["CraftRequirements"] = "REQUIREMENTS",
	["CraftResults"] = "RESULTS",

	["cmdCraftRecipe"] = "Attempt to craft a recipe."
}
