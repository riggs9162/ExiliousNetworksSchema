RECIPE.name = "AKM Upper"
RECIPE.description = "This is a part 2/3 for the AKM."
RECIPE.model = "models/weapons/tfa_ins2/w_akm_bw.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["scrap"] = 3,
    ["refindmetal"] = 1,
	
}
RECIPE.results = {
	["akmupper"] = 1,
}   