RECIPE.name = "SKS"
RECIPE.description = "This is a Wooden SKS."
RECIPE.model = "models/weapons/tfa_ins2/w_sks.mdl"
RECIPE.category = "Guns"
RECIPE.requirements = {
	["sksmag"] = 1,
    ["sksbarrel"] = 1,
    ["sksstock"] = 1
}
RECIPE.results = {
	["sks"] = 1,
}   
RECIPE.tools = {"screwdriver", "pliers"}