RECIPE.name = "SKS Mag"
RECIPE.description = "This is a part 3/3 for the SKS."
RECIPE.model = "models/gibs/metal_gib2.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["refindmetal"] = 1
}
RECIPE.results = {
	["sksmag"] = 1,
}   