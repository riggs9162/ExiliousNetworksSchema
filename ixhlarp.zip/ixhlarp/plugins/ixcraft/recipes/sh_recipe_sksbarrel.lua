RECIPE.name = "SKS Barrel"
RECIPE.description = "This is a part 2/3 for the SKS."
RECIPE.model = "models/gibs/metal_gib2.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["refindmetal"] = 3
}
RECIPE.results = {
	["sksbarrel"] = 1,
}   