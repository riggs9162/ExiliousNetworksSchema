RECIPE.name = "SKS Wooden Stock"
RECIPE.description = "This is a part 1/3 for the SKS."
RECIPE.model = "models/gibs/metal_gib2.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["wood"] = 5
}
RECIPE.results = {
	["sksstock"] = 1,
}   