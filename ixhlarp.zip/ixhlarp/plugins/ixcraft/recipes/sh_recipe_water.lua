RECIPE.name = "Water"
RECIPE.description = "Craft a water."
RECIPE.model = "models/props_junk/PopCan01a.mdl"
RECIPE.requirements = {
	["melon"] = 2,
	["paper"] = 1
}
RECIPE.results = {
	["water"] = {["min"] = 2, ["max"] = 20},
	["melon"] = {1, 5, 10},
	["paper"] = 1
}
RECIPE.tools = {
	"cid"
}