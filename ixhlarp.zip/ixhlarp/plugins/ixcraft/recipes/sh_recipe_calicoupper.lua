RECIPE.name = "Calico Upper"
RECIPE.description = "This is a part 1/3 for the Calico."
RECIPE.model = "models/weapons/tfa_l4d2/w_calico.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["scrap"] = 4
}
RECIPE.results = {
	["calicoupper"] = 1,
}   