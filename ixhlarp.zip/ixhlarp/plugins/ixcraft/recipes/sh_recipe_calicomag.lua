RECIPE.name = "Calico Mag"
RECIPE.description = "This is a part 3/3 for the Calico."
RECIPE.model = "models/weapons/tfa_l4d2/w_calico.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["scrap"] = 2
}
RECIPE.results = {
	["calicomag"] = 1,
}   