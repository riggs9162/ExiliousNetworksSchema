RECIPE.name = "Scrap Pistol Bullets"
RECIPE.description = "A 10x scrap pistol bullets."
RECIPE.model = "models/items/boxsrounds.mdl"
RECIPE.category = "Ammo"
RECIPE.requirements = {
	["scrapcasing"] = 2,
    ["gunpowder"] = 1
}
RECIPE.results = {
	["scrappistolammo"] = 1,
}