RECIPE.name = "Watermelon"
RECIPE.description = "Craft a watermelon."
RECIPE.model = "models/props_junk/watermelon01.mdl"
RECIPE.category = "Watermelon2"
RECIPE.requirements = {
	["melonchunk"] = 4
}
RECIPE.results = {
	["watermelon"] = 1
}