RECIPE.name = "Pliers"
RECIPE.description = "A set of pliers used to bend metal."
RECIPE.model = "models/props_c17/tools_pliers01a.mdl"
RECIPE.category = "Tools"
RECIPE.requirements = {
	["refindmetal"] = 2
}
RECIPE.results = {
	["pliers"] = 1,
}

