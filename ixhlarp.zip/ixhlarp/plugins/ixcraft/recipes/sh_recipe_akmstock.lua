RECIPE.name = "AKM Wooden Stock"
RECIPE.description = "This is a part 1/3 for the AKM."
RECIPE.model = "models/weapons/tfa_ins2/w_akm_bw.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["wood"] = 4,
	
}
RECIPE.results = {
	["akmstock"] = 1,
}   