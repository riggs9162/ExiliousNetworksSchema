RECIPE.name = "AKM Mag"
RECIPE.description = "This is a part 3/3 for the AKM."
RECIPE.model = "models/weapons/tfa_ins2/w_akm_bw.mdl"
RECIPE.category = "Gun-Parts"
RECIPE.requirements = {
	["scrap"] = 2,
	
}
RECIPE.results = {
	["akmmag"] = 1,
}   