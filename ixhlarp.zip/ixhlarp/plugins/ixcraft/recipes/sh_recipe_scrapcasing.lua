RECIPE.name = "Scrap-Casing"
RECIPE.description = "A flimsy bullet case."
RECIPE.model = "models/props_lab/box01a.mdl"
RECIPE.category = "Ammo"
RECIPE.requirements = {
	["scrap"] = 2
}
RECIPE.results = {
	["scrapcasing"] = 1,
}
RECIPE.tools = {
    "pliers"
}