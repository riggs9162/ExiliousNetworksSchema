RECIPE.name = "Refind Metal"
RECIPE.description = "This is refind metal."
RECIPE.model = "models/gibs/metal_gib2.mdl"
RECIPE.category = "Refind"
RECIPE.requirements = {
	["scrap"] = 3
}
RECIPE.results = {
	["refindmetal"] = 1,
}