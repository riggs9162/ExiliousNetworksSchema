STATION.name = "Oven"
STATION.description = "A oven used for Cooking."
STATION.model = "models/props_c17/furnitureStove001a.mdl"