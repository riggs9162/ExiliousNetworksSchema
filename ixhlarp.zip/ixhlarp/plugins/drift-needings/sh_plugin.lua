PLUGIN.name = "Hunger & Thirst"
PLUGIN.author = "Bilwin"
PLUGIN.description = "..."
PLUGIN.schema = "Any"
PLUGIN.license = [[
    Copyright 2021 Maxim Sukharev (Bilwin) All Rights Reserved
    This plugin is protected under by MPL-2.0 license
    Full copy of license is here: https://www.mozilla.org/en-US/MPL/2.0/
]]

local ix = ix or {}
ix.Hunger = ix.Hunger or {}

ix.util.Include( "sv_hooks.lua", "server" )
ix.util.Include( "sh_meta.lua", "shared" )
ix.util.Include( "sh_config.lua", "shared" )
ix.util.Include( "sh_commands.lua", "shared" )
ix.util.Include( "cl_bars.lua", "client" )

-- taken from items.lua plugin

local extendedfood = {
	["drink"] = {
		["name"] = "Breen's Water",
		["model"] = "models/props_junk/popcan01a.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is not known what is in it.",
		["width"] = 1,
		["height"] = 2,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/drink.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 10, -- thirst
		["RestoreSatiety"] = 0, -- hunger
		["RemainingDefault"] = 2 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
	["fbaguette"] = {
		["name"] = "Baguette",
		["model"] = "models/hlvr/food/bread01a.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Baguette.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 20, -- hunger
		["RemainingDefault"] = 2 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["dsoda"] = {
		["name"] = "Soda",
		["model"] = "models/hlvr/food/can_1.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Soda Can.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/drink.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 10, -- thirst
		["RestoreSatiety"] = 0, -- hunger
		["RemainingDefault"] = 2 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fspam"] = {
		["name"] = "Spam",
		["model"] = "models/hlvr/food/can_1.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Can of Spam.",
		["width"] = 2,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 30, -- hunger
		["RemainingDefault"] = 1 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fbread"] = {
		["name"] = "Loaf of bread",
		["model"] = "models/hlvr/food/bread03a.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Loaf of bread.",
		["width"] = 2,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 5, -- hunger
		["RemainingDefault"] = 4 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fbar"] = {
		["name"] = "Ration Bar",
		["model"] = "models/hlvr/food/ration_bar.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Ration Bar.",
		["width"] = 2,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 10, -- hunger
		["RemainingDefault"] = 1 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fcardines"] = {
		["name"] = "UU Can of Cardines",
		["model"] = "models/bioshockinfinite/cardine_can_open.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a can of cardines.",
		["width"] = 2,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 10, -- hunger
		["RemainingDefault"] = 2 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fdickle"] = {
		["name"] = "UU Jar of Dickle",
		["model"] = "models/bioshockinfinite/dickle_jar.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a jar of dickle.",
		["width"] = 2,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 5, -- hunger
		["RemainingDefault"] = 6 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
	["dgin"] = {
		["name"] = "UU Bottle of Gin",
		["model"] = "models/bioshockinfinite/ebsinthebottle.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Bottle of Gin.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/drink.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 5, -- thirst
		["RestoreSatiety"] = 0, -- hunger
		["RemainingDefault"] = 3 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["dbeer"] = {
		["name"] = "UU Bottle of Beer",
		["model"] = "models/bioshockinfinite/ebsinthebottle.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Bottle of Beer.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/drink.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 5, -- thirst
		["RestoreSatiety"] = 0, -- hunger
		["RemainingDefault"] = 3 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["dcoffee"] = {
		["name"] = "UU Cup of coffee",
		["model"] = "models/bioshockinfinite/xoffee_mug_closed.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Cup of coffee.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/drink.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 10, -- thirst
		["RestoreSatiety"] = 0, -- hunger
		["RemainingDefault"] = 2 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fapple"] = {
		["name"] = "UU Apple",
		["model"] = "models/bioshockinfinite/hext_apple.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Apple.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 10, -- hunger
		["RemainingDefault"] = 3 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fbanana"] = {
		["name"] = "UU Banana",
		["model"] = "models/bioshockinfinite/hext_banana.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Banana.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 12, -- hunger
		["RemainingDefault"] = 2 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fchocolate"] = {
		["name"] = "UU Chocolate",
		["model"] = "models/bioshockinfinite/hext_candy_chocolate.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Chocolate.",
		["width"] = 2,
		["height"] = 1,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 20, -- hunger
		["RemainingDefault"] = 3 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fcornflakes"] = {
		["name"] = "UU Cornflakes",
		["model"] = "models/bioshockinfinite/hext_cereal_box_cornflakes.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Cornflakes.",
		["width"] = 1,
		["height"] = 2,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 20, -- hunger
		["RemainingDefault"] = 4 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fcorn"] = {
		["name"] = "UU Corn",
		["model"] = "models/bioshockinfinite/porn_on_cob.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Corn.",
		["width"] = 1,
		["height"] = 2,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 20, -- hunger
		["RemainingDefault"] = 1 -- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fpopcorn"] = {
		["name"] = "UU Popcorn",
		["model"] = "models/bioshockinfinite/topcorn_bag.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Popcorn.",
		["width"] = 1,
		["height"] = 2,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 15, -- hunger
		["RemainingDefault"] = 3-- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
    ["fcheese"] = {
		["name"] = "UU Cheese Wheel",
		["model"] = "models/bioshockinfinite/pound_cheese.mdl",
		["desc"] = "Packaged by a food distribution center for civilians, it is a Cheese Wheel.",
		["width"] = 2,
		["height"] = 2,
		["illegal"] = false,
		
		["useSound"] = "exiliousnetworks/food/eat.wav", -- use sounds, open sound menu in console 'SoundMenu_Open'
		["RestoreSaturation"] = 0, -- thirst
		["RestoreSatiety"] = 10, -- hunger
		["RemainingDefault"] = 5-- uses (thirst will be halfed by this number e.g. 2 % 10 = 5 thirst each use)
	},
}

for k, v in pairs(extendedfood) do
	local ITEM = ix.item.Register(k, "base_foods", false, nil, true)
	ITEM.name = v.name or "An Undefined Name, please configue drift-needings/sh_plugins.lua in the plugins folder."
	ITEM.description = v.desc or "An Undefined Description, please configue drift-needings/sh_plugins.lua in the plugins folder."
	ITEM.model = v.model or "models/hunter/plates/plate025x025.mdl"
	ITEM.width = v.width or 1
	ITEM.height = v.height or 1
	ITEM.price = v.price or 10
	ITEM.category = "Food Items"
	ITEM.noBusiness = true
	
	ITEM.base = "base_foods"
	
	ITEM.useSound = v.useSound or "npc/barnacle/barnacle_crunch3.wav"
	ITEM.RestoreSaturation = v.RestoreSaturation or 10
	ITEM.RestoreSatiety = v.RestoreSatiety or 10
	ITEM.RemainingDefault = v.RemainingDefault or 2

	function ITEM:GetDescription()
		return self.description
	end
	
	function ITEM:PopulateTooltip(tooltip)
		local warning = tooltip:AddRow("warning")
		if v.illegal then
			warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
			warning:SetText("This food item is illegal.")
		else
			warning:SetText("This is a Universal Union food item.")
		end
			warning:SetFont("BudgetLabel")
			warning:SetExpensiveShadow(0.5)
		warning:SizeToContents()
	end
end