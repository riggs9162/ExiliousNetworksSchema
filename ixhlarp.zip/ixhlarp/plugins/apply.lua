local PLUGIN = PLUGIN

PLUGIN.name = "Apply Command"
PLUGIN.author = "Candyexin"
PLUGIN.description = "Allows citizens to apply."

ix.command.Add("apply", {
    description = "Shows your Name and current Job to people in-range.",

    OnRun = function(_, client)
        if (client:Team() == FACTION_CITIZEN or FACTION_CWU) then
            ix.chat.Send(client, "me", string.format("applies, showing their ID containing: NAME: %s, Job: %s", client:Name(), team.GetName(client:Team())))
        else
            return "@notNow"
        end
    end
})