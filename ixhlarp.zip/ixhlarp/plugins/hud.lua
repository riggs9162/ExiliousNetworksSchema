--[[---------------------------------------------------------------------------
	** Copyright (c) 2021 Connor ---- (ZIKE)
	** This file is private and may not be shared, downloaded, used, sold or even copied.
	** Allowed Users to use any of this products code: ZIKE#7537
---------------------------------------------------------------------------]]--

local PLUGIN = PLUGIN

PLUGIN.name = "Serious RP Hud"
PLUGIN.author = "Riggs"
PLUGIN.description = "..."

if CLIENT then
	local human_color_modify = {
		["$pp_colour_addr"] = 0,
		["$pp_colour_addg"] = 0,
		["$pp_colour_addb"] = 0,
		["$pp_colour_brightness"] = 0,
		["$pp_colour_contrast"] = 0.8,
		["$pp_colour_colour"] = 0.7,
		["$pp_colour_mulr"] = 0,
		["$pp_colour_mulg"] = 0,
		["$pp_colour_mulb"] = 0
	}

	function PLUGIN:ShouldHideBars()
		return true
	end
	
	function PLUGIN:RenderScreenspaceEffects()
		local ply = LocalPlayer()
		if ply:Alive() and ply:GetCharacter() then
			if not ply:IsCombine() then
				DrawColorModify(human_color_modify)
			end
		end
	end
	
	function PLUGIN:HUDPaintBackground()
		surface.SetDrawColor(255, 255, 255, 255)
		surface.SetMaterial(Material("ExiliousNetworks/screen/normal.png"))
		surface.DrawTexturedRect(0, 0, ScrW(), ScrH())
	end
	
	local hudx = 10
	local hudy = ScrH() - 190
	local hudw = 340
	local hudh = 180
	
	function PLUGIN:HUDPaint()
		local ply = LocalPlayer()
		local char = ply:GetCharacter()
		if not (ply:Alive()) then return end
		if not (char) then return end
		if (ply:IsCombine()) then return end
		local frametime = RealFrameTime()
		
		self.predictedStamina = Lerp(frametime / 2, self.predictedStamina or 100, LocalPlayer():GetNetVar("stm", 100))
		local staminabarheight = 160 * (self.predictedStamina / 100)
		
		draw.RoundedBox(5, hudx, hudy, hudw, hudh, Color(30, 30, 30, 230))
		ix.util.DrawBlurAt(hudx, hudy, hudw, hudh)
		draw.RoundedBox(5, 315, ScrH() - 180, 20, staminabarheight, Color(200, 200, 40))
		ix.util.DrawBlurAt(315, ScrH() - 180, 20, staminabarheight, 3, 0.2, 100)
	
		local function DrawHudIcon(x, y, icon, color)
			surface.SetDrawColor(color or color_white)
			surface.SetMaterial(Material(icon))
			surface.DrawTexturedRect(x, y, 20, 20)
			ix.util.DrawBlurAt(x, y, 20, 20, 0.0001, 0.1, 50)
		end
		
		draw.DrawText(char:GetName(), "ixBigFont", 50, ScrH() - 185, team.GetColor(ply:Team()))
		DrawHudIcon(25, ScrH() - 175, "exiliousnetworks/icons/hud/name.png", team.GetColor(ply:Team()))
		
		draw.DrawText("Health: "..ply:Health(), "ixMediumFont", 50, ScrH() - 125, color_white)
		DrawHudIcon(25, ScrH() - 120, "exiliousnetworks/icons/hud/health.png", Color(200, 0, 0))
		
		draw.DrawText("Armor: "..ply:Armor(), "ixMediumFont", 50, ScrH() - 105, color_white)
		DrawHudIcon(25, ScrH() - 100, "exiliousnetworks/icons/hud/armor.png", Color(0, 102, 20))
		
		if (char:GetHunger() and char:GetThirst()) then
			draw.DrawText("Hunger: "..char:GetHunger(), "ixMediumFont", 50, ScrH() - 85, color_white)
			draw.DrawText("Thirst: "..char:GetThirst(), "ixMediumFont", 50, ScrH() - 65, color_white)
			DrawHudIcon(25, ScrH() - 80, "exiliousnetworks/icons/hud/hunger.png", Color(203, 151, 0))
			DrawHudIcon(25, ScrH() - 60, "exiliousnetworks/icons/hud/thirst.png", Color(68, 106, 205))
		end
		
		if (char:GetMoney()) then
			local tokenamount = char:GetMoney()
			if tokenamount == 0 then
				tokenamount = "You have no tokens!"
			end
			draw.DrawText("Tokens: "..char:GetMoney(), "ixMediumFont", 50, ScrH() - 45, color_white)
			DrawHudIcon(25, ScrH() - 40, "exiliousnetworks/icons/hud/tokens.png", Color(76, 153, 0))
		end
	end
end