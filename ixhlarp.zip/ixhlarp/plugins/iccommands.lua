--[[---------------------------------------------------------------------------
	** Copyright (c) 2021 Connor ---- (ZIKE)
	** This file is private and may not be shared, downloaded, used, sold or even copied.
---------------------------------------------------------------------------]]--

PLUGIN.name = "Extended Commands"
PLUGIN.author = "ZIKE"
PLUGIN.description = "A Plugin which creates ic commands through 1 lua file."
PLUGIN.license = "MIT License | Copyright (c) 2020 RiggsMackay"

function PLUGIN:InitializedChatClasses()
	timer.Simple(0.1, function()
		ix.chat.Register("it", {
			OnChatAdd = function(self, speaker, text)
				chat.AddText(Color(100, 50, 50), text)
			end,
			CanHear = ix.config.Get("chatRange", 280) * 2,
			prefix = {"/It", "/Do"},
			description = "@cmdIt",
			indicator = "chatPerforming",
			deadCanChat = true
		})
		--[[
		ix.chat.Register("advert", {
			OnChatAdd = function(self, speaker, text)
				if !speaker:Team() == FACTION_CWU then
					speaker:Notify("You are not a Civil Worker.")
				else
					chat.AddText(Color(150, 150, 150), "[ADVERT] "..speaker:Nick()..": "..text)
				end
			end,
			CanHear = ix.config.Get("chatRange", 280) * 200,
			prefix = {"/Advert", "/Announce"},
			description = "Advertise something to the daily broadcast.",
			indicator = "chatPerforming",
			deadCanChat = false
		})
		]]--
	end)
end