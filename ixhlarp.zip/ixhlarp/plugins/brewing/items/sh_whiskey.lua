ITEM.name = "Whiskey";
ITEM.model = Model("models/props_junk/garbage_glassbottle002a.mdl");
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "Some nice whiskey, now you can be depressed and alone.";
ITEM.category = "Brewing";
