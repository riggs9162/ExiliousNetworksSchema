ITEM.name = "Gin";
ITEM.model = Model("models/props_junk/glassjug01.mdl");
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "Some nice gin.";
ITEM.category = "Brewing";
