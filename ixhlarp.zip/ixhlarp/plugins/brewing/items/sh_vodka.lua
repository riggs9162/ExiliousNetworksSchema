ITEM.name = "Vodka";
ITEM.model = Model("models/props_junk/garbage_glassbottle001a.mdl");
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "Be careful, your pet russian might want some.";
ITEM.category = "Brewing";
