ITEM.name = "Breen's Special Water";
ITEM.model = Model("models/props_junk/PopCan01a.mdl");
ITEM.width = 1;
ITEM.height = 1;
ITEM.description = "Some nice lovely... huh, I've forgotten what I was saying.";
ITEM.category = "Brewing";
ITEM.skin = 2
