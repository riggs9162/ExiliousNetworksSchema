
LANGUAGE = {
	cmdMyNotes = "View your personal notes.",
	mynotesCooldown = "Please wait %d more seconds before doing that!",
	mynotes = "%s's Notes"
}
