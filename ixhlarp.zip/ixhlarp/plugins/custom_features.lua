PLUGIN.name = "Custom Features"
PLUGIN.author = "Riggs"
PLUGIN.description = "..."
PLUGIN.license = "MIT License | Copyright (c) 2020 RiggsMackay"

-- taken from vin here = https://github.com/vingard/impulsehl2rpoutlands
--
if CLIENT then
	net.Receive("ixEmitSound", function()
		local ent = net.ReadEntity()
		local sndscript = net.ReadString()

		if not IsValid(ent) then
			return print("no player uwu")
		end

		ent:EmitSound(sndscript)
	end)
end

if SERVER then
	util.AddNetworkString("ixEmitSound")
	
	function ix.EmitSound(ent, sndscript)
		net.Start("ixEmitSound")
			net.WriteEntity(ent)
			net.WriteString(sndscript)
		net.Broadcast()
	end
end
--

if SERVER then
	function ixPlayerHitSky(v)
		local trace1 = util.TraceLine({start = v:GetPos(), endpos = v:GetPos() + Vector(0,0,26555), filter = v, mask = MASK_SOLID_BRUSHONLY})
		local trace2 = util.TraceLine({start = v:GetPos(), endpos = v:GetPos() + Vector(0,0,-8192), filter = v, mask = MASK_SOLID_BRUSHONLY})
		local trace3 = util.TraceLine({start = v:GetPos(), endpos = v:GetPos() + Vector(26555,0,0), filter = v, mask = MASK_SOLID_BRUSHONLY})
		local trace4 = util.TraceLine({start = v:GetPos(), endpos = v:GetPos() + Vector(-26555,0,0), filter = v, mask = MASK_SOLID_BRUSHONLY})
		local trace5 = util.TraceLine({start = v:GetPos(), endpos = v:GetPos() + Vector(0,26555,0), filter = v, mask = MASK_SOLID_BRUSHONLY})
		local trace6 = util.TraceLine({start = v:GetPos(), endpos = v:GetPos() + Vector(0,-26555,0), filter = v, mask = MASK_SOLID_BRUSHONLY})
		
		if not (trace1.HitSky and trace3.HitSky and trace4.HitSky and trace5.HitSky and trace6.HitSky) then
			return true
		end
	end

	function ixRandomAmbient(v)
		local RandomChance = math.random(1,3)
		if (RandomChance == 3) then
			RandomChance = math.random(1,3)
			if (RandomChance == 3) then
				local RandomAmbient = {
					"exiliousnetworks/event/overhead/helicopter0"..math.random(2,4)..".mp3",
					"exiliousnetworks/event/overhead/jet0"..math.random(2,4)..".mp3",
					"exiliousnetworks/event/battle/building_rubble"..math.random(1,5)..".wav",
					"exiliousnetworks/event/battle/distant_battle_gunfire0"..math.random(1,7)..".wav",
					"exiliousnetworks/event/battle/battle_loop2.wav",
					"exiliousnetworks/event/battle/distant_battle_dropship01.wav",
					"exiliousnetworks/event/battle/distant_battle_dropship02.wav",
					"exiliousnetworks/event/battle/distant_battle_dropship03.wav",
					"exiliousnetworks/event/battle/city_chant1.wav",
					"exiliousnetworks/event/battle/gunship_distant2.wav",
					"exiliousnetworks/event/battle/strider_distant"..math.random(1,3)..".wav",
					"exiliousnetworks_ambient/atmosphere/city_truckpass1.wav",
					"exiliousnetworks_ambient/atmosphere/cave_hit"..math.random(1,6)..".wav",
					"exiliousnetworks_ambient/atmosphere/hole_hit"..math.random(1,5)..".wav",
					"ambient/atmosphere/cave_hit"..math.random(1,6)..".wav",
					"ambient/atmosphere/hole_hit"..math.random(1,5)..".wav",
					"hlacomvoice/strider/amb_c17_strider_distant_0"..math.random(1,9)..".mp3",
					"hlacomvoice/strider/amb_c17_strider_distant_1"..math.random(0,6)..".mp3",
				}
				ix.EmitSound(v, table.Random(RandomAmbient))
			end
		end
	end

	function PLUGIN:InitializedPlugins()
		if not (timer.Exists("ixRandomAmbient")) then
			timer.Create("ixRandomAmbient", 20, 0, function()
				for k, v in pairs(player.GetAll(ents.FindInSphere, 32000)) do
					if v:IsValid() then
						if ixPlayerHitSky(v) then
							ixRandomAmbient(v)
						end
					end
				end
			end)
		end
	end
end

PLUGIN.name = "Combine Hud Display"
PLUGIN.author = "Riggs"
PLUGIN.description = "..."

PLUGIN.name = "Combine Hud Display"
PLUGIN.author = "Riggs"
PLUGIN.description = "..."

if CLIENT then
surface.CreateFont("CombineBudgetLabel", {
	font = "Roboto Th",
	size = 25,
	outline = true,
	shadow = true,
	italic = true,
	scanlines = 2,
	blursize = 0.5,
})

local IdleDisplayMessages = {
	"Updating data connections...",
	"Looking up main protocols...",
	"Updating Translation Matrix...",
	"Establishing connection with overwatch...",
	"Opening up aura scanners...",
	"Establishing Clockwork protocols...",
	"Looking up active fireteam control centers...",
	"Command uplink established...",
	"Inititaing self-maintenance scan...",
	"Scanning for active biosignals...",
	"Updating cid registry link...",
	"Establishing variables for connection hooks...",
	"Creating socket for incoming connection...",
	"Initializing squad uplink interface...",
	"@sivoe-main: 3fj89323r829j20-",
	"Validating memory replacement integrity...",
	"Visual uplink status code: GREEN...",
	"Refreshing primary database connections...",
	"Creating ID's for internal structs...",
	"Dumping cache data and renewing from external memory...",
	"Updating squad statuses...",
	"Looking up front end codebase changes...",
	"Software status nominal...",
	"Querying database for new recruits... RESPONSE: OK",
	"Establishing connection to long term maintenance procedures...",
	"Looking up CP-5 Main...",
	"Updating railroad activity monitors...",
	"Caching new response protocols...",
	"Calculating the duration of patrol...",
	"Caching internal watch protocols...",
	"Riggs can't code for shit.",
	"That's why your shoes ragedy.",
	"Looking up who cares.... ERROR!"
}

local function GetSocioStatus()
	return ix.config.Get("socio_status") -- obviously replace this with your functions
end

local function GetWaiverStatus()
	return ix.config.Get("waiver_status")
end

local function GetCityCode()
	return ix.config.Get("city_code")
end

function PLUGIN:PlayerTick(ply)
	if ply:IsCombine() and ply:Alive() then
		if not ply.NextMessage or ply.NextMessage <= CurTime() then
			Schema:AddCombineDisplayMessage(table.Random(IdleDisplayMessages), Color(255, 255, 255, 255))
			ply.NextMessage = CurTime() + 10
		end
	end
end

function PLUGIN:HUDPaint()
	local client = LocalPlayer()
	if not (client:Alive() and client:IsValid()) then return false end
	if IsValid(ix.gui.menu) or IsValid(ix.gui.characterMenu) then return false end
	if client:IsCombine() and client:Alive() then
    	overwatchHUDData = overwatchHUDData or {}
    	for i = 1, 100 do
    		overwatchHUDData[i] = overwatchHUDData[i] or {
    			w = 0,
    			targetW = math.random(1, 150),
    			a = math.random(0, 10)
    		}
    		local data = overwatchHUDData[i]
    
    		data.w = Lerp(0.01, data.w, data.targetW + (10 / 1) * math.sin(CurTime() + math.Rand(0, 2)))
    		
    		overwatchHUDData[i] = data
    		
    		local h = ScrH() * 0.05 + (ScrH() * (i / 100))
    		
    		draw.RoundedBox(0, 0, h, data.w, 5, Color(50, 50, 50, data.a))
    		draw.RoundedBox(0, ScrW( ) - data.w, h, data.w, 5, Color(50, 50, 50, data.a))
    	end
    	
    	local TeamName = team.GetName(client:Team())
    	local TeamColor = team.GetColor(client:Team())
    	
    	local InfoWidthPos = 20
    	local GunWidthPos = ScrW() / 2
    	local CombineFont = "CombineBudgetLabel"
    	local pos = client:GetPos()
    	local MapGrid = math.Round(pos.x / 100).." / "..math.Round(pos.y / 100).." / "..math.Round(pos.z / 100)
		local Area = client:GetArea() or "Unknown Location"
    	
    	function DrawBox(x, y, w, h)
    		draw.RoundedBox(0, x, y, w, h, Color(20, 20, 20, 240))
    		surface.SetDrawColor(0, 0, 0, 255)
    		surface.DrawOutlinedRect(x, y, w, h, 2)
    	end
    	
    	DrawBox(10, 10, 410, 100)
    	DrawBox(10, ScrH() - 170, 400, 160)
    	
    	draw.DrawText("<:: Sociostability: " .. Schema.SocioStatusCodes[GetSocioStatus()][1] .. " ::>", CombineFont, InfoWidthPos, 20, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
    	draw.DrawText("<:: Waiver Status: " .. Schema.WaiverStatus[GetWaiverStatus()][1] .. " ::>", CombineFont, InfoWidthPos, 45, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
    	draw.DrawText("<:: City Code: " .. Schema.CityCodes[GetCityCode()][1] .. " ::>", CombineFont, InfoWidthPos, 70, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
    	
		draw.DrawText("Zone: "..Area, CombineFont, InfoWidthPos, ScrH() - 144 - 20, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
    	draw.DrawText("Grid: "..MapGrid, CombineFont, InfoWidthPos, ScrH() - 120 - 20, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
    	if (client:Armor() == 0) then
    		draw.DrawText("Kevlar: NIL", CombineFont, InfoWidthPos, ScrH() - 96 - 20, Color(255, 50, 50, 255), TEXT_ALIGN_LEFT)
    	else
    		draw.DrawText("Kevlar: "..client:Armor().." / "..client:GetMaxArmor(), CombineFont, InfoWidthPos, ScrH() - 96 - 20, Color(50, 50, 255, 255), TEXT_ALIGN_LEFT)
    	end
    	draw.DrawText("Vitals: "..client:Health().." / "..client:GetMaxHealth(), CombineFont, InfoWidthPos, ScrH() - 72 - 20, Color(0, 255, 0, 255), TEXT_ALIGN_LEFT)
    	draw.DrawText("Assignment: "..TeamName, CombineFont, InfoWidthPos, ScrH() - 48 - 20, Color(255, 255, 255, 255), TEXT_ALIGN_LEFT)
    	draw.DrawText("Unit: "..client:Nick(), CombineFont, InfoWidthPos, ScrH() - 24 - 20, TeamColor, TEXT_ALIGN_LEFT)
    	
    	if client:GetActiveWeapon():IsValid() and (client:GetActiveWeapon():GetPrintName() != nil) then
    		if not (client:GetActiveWeapon():Clip1() == -1) then
    			if client:GetAmmoCount(client:GetActiveWeapon():GetSecondaryAmmoType()) >= 1 then
    				DrawBox(ScrW() / 2 - 200, ScrH() - 125, 400, 85)
    			else
    				DrawBox(ScrW() / 2 - 200, ScrH() - 105, 400, 65)
    			end
    			if client:GetAmmoCount(client:GetActiveWeapon():GetSecondaryAmmoType()) >= 1 then
    				draw.DrawText("Secondary Ammo: "..client:GetAmmoCount(client:GetActiveWeapon():GetSecondaryAmmoType()), CombineFont, GunWidthPos, ScrH() - 120, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
    			end
    			draw.DrawText("Primary Ammo: "..client:GetActiveWeapon():Clip1().. " / " ..client:GetAmmoCount(client:GetActiveWeapon():GetPrimaryAmmoType()), CombineFont, GunWidthPos, ScrH() - 96, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
    			draw.DrawText("Active Weapon: "..client:GetActiveWeapon():GetPrintName(), CombineFont, GunWidthPos, ScrH() - 72, Color(255, 255, 255, 255), TEXT_ALIGN_CENTER)
    		end
        end
    end
end
end