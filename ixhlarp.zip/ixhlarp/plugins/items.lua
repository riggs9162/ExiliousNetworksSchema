--[[---------------------------------------------------------------------------
	** Copyright (c) 2021 Connor (Riggs)
	** This file is private and may not be shared, downloaded, used, sold or even copied.
---------------------------------------------------------------------------]]--

PLUGIN.name = "Extended Items"
PLUGIN.author = "Riggs"
PLUGIN.description = "A Plugin which creates items through 1 lua file."
PLUGIN.license = "MIT License | Copyright (c) 2021 RiggsMackay"

local extendeditems = {
	["screwdriver"] = {
		["name"] = "Screwdriver",
		["model"] = "models/props_c17/TrapPropeller_Lever.mdl",
		["desc"] = "Screwdriver.",
		["width"] = 2,
		["height"] = 1,
		["illegal"] = false
	},
	["tv"] = {
		["name"] = "Television Monitor",
		["model"] = "models/props_c17/tv_monitor01.mdl",
		["desc"] = "A Famous metal box, used to watch shows",
		["width"] = 3,
		["height"] = 2,
		["illegal"] = false
	},
	["gnome"] = {
		["name"] = "Gnome",
		["model"] = "models/props_junk/gnome.mdl",
		["desc"] = "Fear the gnome.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = true
	},
    ["melonchunk"] = {
		["name"] = "Watermelon Chunk",
		["model"] = "models/props_junk/watermelon01_chunk01c.mdl",
		["desc"] = "It's a melon for fuck sake.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false
	},
	["watermelon"] = {
		["name"] = "Watermelon",
		["model"] = "models/props_junk/watermelon01.mdl",
		["desc"] = "It's a Watermelon... Fear me!.",
		["width"] = 2,
		["height"] = 2,
		["illegal"] = true
	},
	["scrap"] = {
		["name"] = "Scrap Metal",
		["model"] = "models/props_debris/metal_panelshard01b.mdl",
		["desc"] = "A chunk of Scrap Metal.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false
	},
	["scrapcasing"] = {
		["name"] = "Scrap Casing",
		["model"] = "models/weapons/shell.mdl",
		["desc"] = "Scrap Bullet Casing.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = true
	},
    ["gunpowder"] = {
		["name"] = "Gunpowder",
		["model"] = "models/props_junk/cardboard_box004a.mdl",
		["desc"] = "A box of Gunpowder.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = true
	},
	["pliers"] = {
		["name"] = "Pliers",
		["model"] = "models/props_c17/tools_pliers01a.mdl",
		["desc"] = "A pair of Pliers.",
		["width"] = 1,
		["height"] = 2,
		["illegal"] = false
	},
	["wood"] = {
		["name"] = "Wooden Board",
		["model"] = "models/Gibs/wood_gib01d.mdl",
		["desc"] = "Broken Wooden Board..",
		["width"] = 1,
		["height"] = 2,
		["illegal"] = false
	},
	["plastic"] = {
		["name"] = "Chunk of plastic",
		["model"] = "models/props_junk/garbage_milkcarton001a.mdl",
		["desc"] = "This is a small bottle of plastic",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false
	},
	["glassbottle"] = {
		["name"] = "Glass Bottle",
		["model"] = "models/props_junk/garbage_glassbottle003a.mdl",
		["desc"] = "This is a nice green bottle.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false
	},
    ["screwdriver"] = {
		["name"] = "Screwdriver",
		["model"] = "models/props_c17/TrapPropeller_Lever.mdl",
		["desc"] = "This is a Screwdriver use it to make stuff.",
		["width"] = 1,
		["height"] = 2,
		["illegal"] = false
	},
	["refindmetal"] = {
		["name"] = "Refind Metal",
		["model"] = "models/gibs/metal_gib2.mdl",
		["desc"] = "This is Refind Metal, Used in crafting better items.",
		["width"] = 1,
		["height"] = 1,
		["illegal"] = false
	},
	["sksstock"] = {
		["name"] = "SKS Wooden Stock",
		["model"] = "models/weapons/tfa_ins2/w_sks.mdl",
		["desc"] = "This is a part 1/3 for the SKS.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["sksbarrel"] = {
		["name"] = "SKS Barrel",
		["model"] = "models/weapons/tfa_ins2/w_sks.mdl",
		["desc"] = "This is a part 2/3 for the SKS.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["sksmag"] = {
		["name"] = "SKS Mag",
		["model"] = "models/weapons/tfa_ins2/w_sks.mdl",
		["desc"] = "This is a part 3/3 for the SKS.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["calicoupper"] = {
		["name"] = "Calico Upper",
		["model"] = "models/weapons/tfa_l4d2/w_calico.mdl",
		["desc"] = "This is a part 1/3 for the Calico.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["calicolower"] = {
		["name"] = "Calico Lower",
		["model"] = "models/weapons/tfa_l4d2/w_calico.mdl",
		["desc"] = "This is a part 2/3 for the Calico.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["calicomag"] = {
		["name"] = "Calico Mag",
		["model"] = "models/weapons/tfa_l4d2/w_calico.mdl",
		["desc"] = "This is a part 3/3 for the Calico.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["akmstock"] = {
		["name"] = "AKM Stock",
		["model"] = "models/weapons/tfa_ins2/w_akm_bw.mdl",
		["desc"] = "This is a part 1/3 for the AKM.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["akmupper"] = {
		["name"] = "AKM Upper",
		["model"] = "models/weapons/tfa_ins2/w_akm_bw.mdl",
		["desc"] = "This is a part 2/3 for the AKM.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
	["akmmag"] = {
		["name"] = "AKM Mag",
		["model"] = "models/weapons/tfa_ins2/w_akm_bw.mdl",
		["desc"] = "This is a part 3/3 for the AKM.",
		["width"] = 3,
		["height"] = 1,
		["illegal"] = false
	},
}

local ammoitems = {
	["pistolammo"] = {
		["name"] = "Pistol Ammo",
		["model"] = "models/Items/BoxSRounds.mdl",
		["desc"] = "A Box containing %s of Pistol Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "pistol",
		["ammoAmount"] = 30
	},
	["smg1ammo"] = {
		["name"] = "Submachine Ammo",
		["model"] = "models/Items/BoxMRounds.mdl",
		["desc"] = "A Box containing %s of Submachine Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "smg1",
		["ammoAmount"] = 45
	},
	["rifleammo"] = {
		["name"] = "Rifle Ammo",
		["model"] = "models/Items/BoxMRounds.mdl",
		["desc"] = "A Box containing %s of Rifle Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "ar2",
		["ammoAmount"] = 30
	},
	["shotgunammo"] = {
		["name"] = "Shotgun Shells",
		["model"] = "models/Items/BoxBuckshot.mdl",
		["desc"] = "A Box containing %s Shotgun Shells.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "buckshot",
		["ammoAmount"] = 15
	},
	["357ammo"] = {
		["name"] = "Revolver Ammo",
		["model"] = "models/items/357ammo.mdl",
		["desc"] = "A Box containing %s of 357. Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "357",
		["ammoAmount"] = 12
	},
	["sniperammo"] = {
		["name"] = "Sniper Rounds",
		["model"] = "models/items/357ammo.mdl",
		["desc"] = "A Box containing %s of Sniper Rounds.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "SniperRound",
		["ammoAmount"] = 8
	},
	["scrappistolammo"] = {
		["name"] = "Scrap Pistol Ammo",
		["model"] = "models/Items/BoxSRounds.mdl",
		["desc"] = "A Box containing %s of Scrap Pistol Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "pistol",
		["ammoAmount"] = 10
	},
    ["sshotgunammo"] = {
		["name"] = "Scrap Shotgun Ammo",
		["model"] = "models/Items/BoxSRounds.mdl",
		["desc"] = "A Box containing %s of Scrap Shotgun Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "shotgun",
		["ammoAmount"] = 10
	},
	["srifleammo"] = {
		["name"] = "Scrap Rifle Ammo",
		["model"] = "models/Items/BoxSRounds.mdl",
		["desc"] = "A Box containing %s of Scrap Rifle Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "rifle",
		["ammoAmount"] = 10
	},
	["ssmgammo"] = {
		["name"] = "Scrap SMG Ammo",
		["model"] = "models/Items/BoxSRounds.mdl",
		["desc"] = "A Box containing %s of Scrap SMG Ammo.",
		["width"] = 1,
		["height"] = 1,
		["ammo"] = "smg1",
		["ammoAmount"] = 10
	},
	   
	
}

local weaponitems = {
	["usp"] = {
		["name"] = "USP Match",
		["model"] = "models/weapons/tfa_ins2/w_usp_match.mdl",
		["desc"] = "A 9mm USP Match Pistol commonly used by Civil Protection and other Refugee Humans.",
		["width"] = 2,
		["height"] = 1,
		["isGrenade"] = false,
		["weaponCategory"] = "pistol",
		["class"] = "tfa_ins2_usp_match"
	},
	["mp7"] = {
		["name"] = "MP7",
		["model"] = "models/weapons/tfa_ins2/w_mp7.mdl",
		["desc"] = "An SMG Fabricated By Heckler And Koch, very notorious for it's design.",
		["width"] = 3,
		["height"] = 2,
		["isGrenade"] = false,
		["weaponCategory"] = "smg",
		["class"] = "tfa_ins2_mp7"
	},
	["spas12"] = {
		["name"] = "SPAS-12",
		["model"] = "models/weapons/w_shotgun.mdl",
		["desc"] = "An Shotgun Fabricated By Franchi, very notorious for it's design.",
		["width"] = 4,
		["height"] = 2,
		["isGrenade"] = false,
		["weaponCategory"] = "shotgun",
		["class"] = "weapon_shotgun"
	},
	["osipr"] = {
		["name"] = "Overwatch Standard Issue Pulse Rifle",
		["model"] = "models/weapons/w_irifle.mdl",
		["desc"] = "A Combine Crafter Rifle, very capable of killing your ass if you're aimed at with it.",
		["width"] = 4,
		["height"] = 2,
		["isGrenade"] = false,
		["weaponCategory"] = "rifle",
		["class"] = "weapon_ar2"
	},
	["crossbow"] = {
		["name"] = "Electro-Bolt Crossbow",
		["model"] = "models/weapons/w_crossbow.mdl",
		["desc"] = "A Homemade Crossbow, Damn.",
		["width"] = 4,
		["height"] = 2,
		["isGrenade"] = false,
		["weaponCategory"] = "sniper",
		["class"] = "weapon_crossbow"
	},
	["stunstick"] = {
		["name"] = "Civil Protection Pacification Tool",
		["model"] = "models/weapons/w_stunbaton.mdl",
		["desc"] = "A Stunstick made by the combine for the Civil Protection, common as hell around these parts.",
		["width"] = 1,
		["height"] = 2,
		["isGrenade"] = false,
		["weaponCategory"] = "melee",
		["class"] = "weapon_stunstick"
	},
	["sks"] = {
		["name"] = "Wooden SKS",
		["model"] = "models/weapons/tfa_ins2/w_sks.mdl",
		["desc"] = "A Wooden SKS.",
		["width"] = 4,
		["height"] = 1,
		["isGrenade"] = false,
		["weaponCategory"] = "rifle",
		["class"] = "tfa_ins2_sks"
	},
	["calicom905"] = {
	    ["name"] = "Calico M950",
		["model"] = "models/weapons/tfa_l4d2/w_calico.mdl",
		["desc"] = "A Calico M950.",
		["width"] = 2,
		["height"] = 2,
		["isGrenade"] = false,
		["weaponCategory"] = "rifle",
		["class"] = "tfa_l4d2_calico"
	},
}

for k, v in pairs(extendeditems) do
	local ITEM = ix.item.Register(k, nil, false, nil, true)
	ITEM.name = v.name or "An Undefined Name, please configue items.lua in the plugins folder."
	ITEM.description = v.desc or "An Undefined Description, please configue items.lua in the plugins folder."
	ITEM.model = v.model or "models/hunter/plates/plate025x025.mdl"
	ITEM.width = v.width or 1
	ITEM.height = v.height or 1
	ITEM.price = v.price or 10
	ITEM.category = "Extended Items"
	ITEM.noBusiness = true
	ITEM.bDropOnDeath = true
	
	function ITEM:GetDescription()
		return self.description
	end
	
	function ITEM:PopulateTooltip(tooltip)
		if v.illegal then
			local warning = tooltip:AddRow("warning")
			warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
			warning:SetText("This item is illegal.")
			warning:SetFont("BudgetLabel")
			warning:SetExpensiveShadow(0.5)
			warning:SizeToContents()
		end
	end
end

for k, v in pairs(ammoitems) do
	local ITEM = ix.item.Register(k, "base_ammo", false, nil, true)
	ITEM.name = v.name or "An Undefined Name, please configue items.lua in the plugins folder."
	ITEM.description = v.desc or "An Undefined Description, please configue items.lua in the plugins folder."
	ITEM.model = v.model or "models/hunter/plates/plate025x025.mdl"
	ITEM.width = v.width or 1
	ITEM.height = v.height or 1
	ITEM.price = v.price or 10
	ITEM.category = "Ammo Items"
	ITEM.noBusiness = true
	ITEM.bDropOnDeath = true
	
	ITEM.base = "base_ammo"
	ITEM.useSound = v.useSound or "items/ammo_pickup.wav"
	ITEM.ammo = v.ammo or "pistol"
	ITEM.ammoAmount = v.ammoAmount or 30

	function ITEM:GetDescription()
		return self.description
	end
	
	function ITEM:PopulateTooltip(tooltip)
		local warning = tooltip:AddRow("warning")
		warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
		warning:SetText("This item is illegal.")
		warning:SetFont("BudgetLabel")
		warning:SetExpensiveShadow(0.5)
		warning:SizeToContents()
	end
end

for k, v in pairs(weaponitems) do
	local ITEM = ix.item.Register(k, "base_weapons", false, nil, true)
	ITEM.name = v.name or "An Undefined Name, please configue items.lua in the plugins folder."
	ITEM.description = v.desc or "An Undefined Description, please configue items.lua in the plugins folder."
	ITEM.model = v.model or "models/hunter/plates/plate025x025.mdl"
	ITEM.width = v.width or 1
	ITEM.height = v.height or 1
	ITEM.price = v.price or 10
	ITEM.category = "Weapon Items"
	ITEM.noBusiness = true
	ITEM.bDropOnDeath = true
	
	ITEM.base = "base_weapons"
	ITEM.isWeapon = true
	ITEM.isGrenade = v.isGrenade or false
	ITEM.weaponCategory = v.weaponCategory or "sidearm"
	ITEM.useSound = v.useSound or "items/ammo_pickup.wav"
	ITEM.class = v.class or "weapon_pistol"

	function ITEM:GetDescription()
		return self.description
	end
	
	function ITEM:PopulateTooltip(tooltip)
		local warning = tooltip:AddRow("warning")
		warning:SetBackgroundColor(derma.GetColor("Error", tooltip))
		warning:SetText("This weapon is illegal.")
		warning:SetFont("BudgetLabel")
		warning:SetExpensiveShadow(0.5)
		warning:SizeToContents()
	end
end