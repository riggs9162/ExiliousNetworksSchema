ENT.Type 			= "point"
ENT.Base 			= "base_gmodentity"
ENT.PrintName		= "NPC Autospawner"
ENT.Author			= "Silverlan"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
