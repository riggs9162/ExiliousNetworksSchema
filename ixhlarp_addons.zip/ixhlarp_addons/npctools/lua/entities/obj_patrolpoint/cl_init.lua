include('shared.lua')

function ENT:Initialize()
end

function ENT:Draw()
end