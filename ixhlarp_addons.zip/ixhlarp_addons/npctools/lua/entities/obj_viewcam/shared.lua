
ENT.Type 			= "anim"
ENT.Base 			= "base_gmodentity"
ENT.PrintName		= "Viewcam"
ENT.Author			= "Silverlan"

ENT.Spawnable			= false
ENT.AdminSpawnable		= false
