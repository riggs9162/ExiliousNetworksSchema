include('shared.lua')

function ENT:Draw()
end

function ENT:Initialize()
end

function ENT:Think()
end