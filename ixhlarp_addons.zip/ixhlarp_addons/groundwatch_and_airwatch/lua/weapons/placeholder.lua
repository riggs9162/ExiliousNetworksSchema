AddCSLuaFile()

SWEP.PrintName 			= "Airwatch 'controller'"
SWEP.Slot 				= 1
SWEP.SlotPos 			= 1

SWEP.DrawCrosshair 		= false

SWEP.WorldModel 		= ""

SWEP.Primary.ClipSize 		= -1
SWEP.Primary.DefaultClip 	= -1
SWEP.Primary.Ammo			= ""
SWEP.Primary.Automatic		= false

SWEP.Secondary.ClipSize 	= -1
SWEP.Secondary.DefaultClip 	= -1
SWEP.Secondary.Ammo			= ""
SWEP.Secondary.Automatic	= false

function SWEP:PrimaryAttack()
	return false
end

function SWEP:SecondaryAttack()
	return false
end

function SWEP:Reload()
	return false
end

function SWEP:PreDrawViewModel()
	return true
end

function SWEP:DrawHUD()
	local ply = LocalPlayer()
	local ent = ply.awEnt

	if not ent or not ent:IsValid() then
		return
	end

	local seat

	if ent.useGunner then
		seat = ent:GetAwGunner()
	else
		seat = ent:GetAwDriver()
	end

	if ent:IsValid() and ply == seat then
		local x = ScrW() / 2
		local y = ScrH() / 2

		local gap = 5
		local len = gap + 5

		local col = Color(255, 0, 0)

		if ent:hasLOS() then
			col = Color(0, 255, 0)
		end

		surface.SetDrawColor(col)

		surface.DrawLine(x - len, y, x - gap, y)
		surface.DrawLine(x + len, y, x + gap, y)
		surface.DrawLine(x, y - len, x, y - gap)
		surface.DrawLine(x, y + len, x, y + gap)
	end
end