AddCSLuaFile()

ENT.Type 					= "anim"
ENT.Base 					= "aw2_hunterchopper"

ENT.PrintName				= "Hunter Chopper (2 seater)"
ENT.Category 				= "Airwatch 2"

ENT.Spawnable				= true
ENT.AdminOnly 				= true

ENT.useGunner 				= true