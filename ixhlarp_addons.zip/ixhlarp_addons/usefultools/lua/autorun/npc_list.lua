local CategoryCombineGrunt = "NPC List (Combine Grunt)"
local SquadCombineAlyx = "SquadCombineAlyx"
local HealthCombineGrunt = "60"

local CategoryCombineElite = "NPC List (Combine Elite)"
local HealthCombineElite = "100"

local CategoryCombine = "NPC List (Combine)"
local SquadCombine = "SquadCombine"
local HealthCombine = "70"

local CategoryCombineProspekt = "NPC List (Combine Guard)"
local HealthCombineProspekt = "70"

local CategoryMetroPolice = "NPC List (Metro Police)"
local SquadMetroPolice = "SquadMetroPolice"
local HealthMetroPolice = "50"

local CategoryRefugee = "NPC List (Refugee)"
local HealthRefugee = "40"

local CategoryRebel = "NPC List (Rebels)"
local SquadRebel = "SquadRebel"
local HealthRebel = "60"

local CategoryRebelMedic = "NPC List (Rebel Medics)"
local HealthRebelMedic = "100"

--[[---------------------------------------------------------------------------
	Combine Grunt Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Combine Grunt (Unarmed)",
	Class = "npc_combine_s",
	Model = "models/jq/hlvr/characters/combine/grunt/combine_grunt_hlvr_npc.mdl",
	Weapons = {""},
	Health = HealthCombineGrunt,
	KeyValues = { SquadName = SquadCombineAlyx },
	Category = CategoryCombineGrunt
}
list.Set( "NPC", "npc_combine_g_unarmed", NPC )

local NPC = { Name = "Combine Grunt (SMG)",
	Class = "npc_combine_s",
	Model = "models/jq/hlvr/characters/combine/grunt/combine_grunt_hlvr_npc.mdl",
	Weapons = {"weapon_smg1"},
	Health = HealthCombineGrunt,
	KeyValues = { SquadName = SquadCombineAlyx },
	Category = CategoryCombineGrunt
}
list.Set( "NPC", "npc_combine_g_smg", NPC )

local NPC = { Name = "Combine Grunt (Shotgun)",
	Class = "npc_combine_s",
	Model = "models/jq/hlvr/characters/combine/grunt/combine_grunt_hlvr_npc.mdl",
	Weapons = {"weapon_shotgun"},
	Health = HealthCombineGrunt,
	KeyValues = { SquadName = SquadCombineAlyx },
	Category = CategoryCombineGrunt
}
list.Set( "NPC", "npc_combine_g_shotgun", NPC )

local NPC = { Name = "Combine Grunt (AR2)",
	Class = "npc_combine_s",
	Model = "models/jq/hlvr/characters/combine/grunt/combine_grunt_hlvr_npc.mdl",
	Weapons = {"weapon_ar2"},
	Health = HealthCombineGrunt,
	KeyValues = { SquadName = SquadCombineAlyx },
	Category = CategoryCombineGrunt
}
list.Set( "NPC", "npc_combine_g_ar2", NPC )

--[[---------------------------------------------------------------------------
	Combine Elite Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Combine Elite (Unarmed)",
	Class = "npc_combine_s",
	Model = "models/combine_super_soldier.mdl",
	Weapons = {""},
	Health = HealthCombineElite,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineElite
}
list.Set( "NPC", "npc_combine_e_unarmed", NPC )

local NPC = { Name = "Combine Elite (SMG)",
	Class = "npc_combine_s",
	Model = "models/combine_super_soldier.mdl",
	Weapons = {"weapon_smg1"},
	Health = HealthCombineElite,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineElite
}
list.Set( "NPC", "npc_combine_e_smg", NPC )

local NPC = { Name = "Combine Elite (Shotgun)",
	Class = "npc_combine_s",
	Model = "models/combine_super_soldier.mdl",
	Weapons = {"weapon_shotgun"},
	Health = HealthCombineElite,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineElite
}
list.Set( "NPC", "npc_combine_e_shotgun", NPC )

local NPC = { Name = "Combine Elite (AR2)",
	Class = "npc_combine_s",
	Model = "models/combine_super_soldier.mdl",
	Weapons = {"weapon_ar2"},
	Health = HealthCombineElite,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineElite
}
list.Set( "NPC", "npc_combine_e_ar2", NPC )

--[[---------------------------------------------------------------------------
	Combine Prison Guard Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Combine Guard (Unarmed)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier_prisonguard.mdl",
	Weapons = {""},
	Health = HealthCombineProspekt,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineProspekt
}
list.Set( "NPC", "npc_combine_p_unarmed", NPC )

local NPC = { Name = "Combine Guard (SMG)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier_prisonguard.mdl",
	Weapons = {"weapon_smg1"},
	Health = HealthCombineProspekt,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineProspekt
}
list.Set( "NPC", "npc_combine_p_smg", NPC )

local NPC = { Name = "Combine Guard (Shotgun)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier_prisonguard.mdl",
	Weapons = {"weapon_shotgun"},
	Health = HealthCombineProspekt,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineProspekt
}
list.Set( "NPC", "npc_combine_p_shotgun", NPC )

local NPC = { Name = "Combine Guard (AR2)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier_prisonguard.mdl",
	Weapons = {"weapon_ar2"},
	Health = HealthCombineProspekt,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombineProspekt
}
list.Set( "NPC", "npc_combine_p_ar2", NPC )

--[[---------------------------------------------------------------------------
	Combine Soldier Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Combine Soldier (Unarmed)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier.mdl",
	Weapons = {""},
	Health = HealthCombine,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombine
}
list.Set( "NPC", "npc_combine_s_unarmed", NPC )

local NPC = { Name = "Combine Soldier (SMG)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier.mdl",
	Weapons = {"weapon_smg1"},
	Health = HealthCombine,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombine
}
list.Set( "NPC", "npc_combine_s_smg", NPC )

local NPC = { Name = "Combine Soldier (Shotgun)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier.mdl",
	Weapons = {"weapon_shotgun"},
	Health = HealthCombine,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombine
}
list.Set( "NPC", "npc_combine_s_shotgun", NPC )

local NPC = { Name = "Combine Soldier (AR2)",
	Class = "npc_combine_s",
	Model = "models/combine_soldier.mdl",
	Weapons = {"weapon_ar2"},
	Health = HealthCombine,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryCombine
}
list.Set( "NPC", "npc_combine_s_ar2", NPC )

--[[---------------------------------------------------------------------------
	Metro Police Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Metro Police (Unarmed)",
	Class = "npc_metropolice",
	Model = "models/police.mdl",
	Weapons = {""},
	Health = HealthMetroPolice,
	KeyValues = { SquadName = SquadCombine },
	Category = CategoryMetroPolice
}
list.Set( "NPC", "npc_metropolice_unarmed", NPC )

local NPC = { Name = "Metro Police (Stunstick)",
	Class = "npc_metropolice",
	Model = "models/police.mdl",
	Weapons = {"weapon_stunstick"},
	Health = HealthMetroPolice,
	KeyValues = { SquadName = SquadMetroPolice },
	Category = CategoryMetroPolice
}
list.Set( "NPC", "npc_metropolice_stunstick", NPC )

local NPC = { Name = "Metro Police (Pistol)",
	Class = "npc_metropolice",
	Model = "models/police.mdl",
	Weapons = {"weapon_pistol"},
	Health = HealthMetroPolice,
	KeyValues = { SquadName = SquadMetroPolice },
	Category = CategoryMetroPolice
}
list.Set( "NPC", "npc_metropolice_pistol", NPC )

local NPC = { Name = "Metro Police (SMG)",
	Class = "npc_metropolice",
	Model = "models/police.mdl",
	Weapons = {"weapon_smg1"},
	Health = HealthMetroPolice,
	KeyValues = { SquadName = SquadMetroPolice },
	Category = CategoryMetroPolice
}
list.Set( "NPC", "npc_metropolice_smg", NPC )

--[[---------------------------------------------------------------------------
	Refugee Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Refugee (Unarmed)",
	Class = "npc_citizen",
	Weapons = {""},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REFUGEE, SquadName = SquadRebel},
	Category = CategoryRefugee
}
list.Set( "NPC", "npc_refugee_unarmed", NPC )

local NPC = { Name = "Refugee (Pistol)",
	Class = "npc_citizen",
	Weapons = {"weapon_pistol"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REFUGEE, SquadName = SquadRebel},
	Category = CategoryRefugee
}
list.Set( "NPC", "npc_refugee_pistol", NPC )

local NPC = { Name = "Refugee (SMG)",
	Class = "npc_citizen",
	Weapons = {"weapon_smg1"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REFUGEE, SquadName = SquadRebel},
	Category = CategoryRefugee
}
list.Set( "NPC", "npc_refugee_smg", NPC )

local NPC = { Name = "Refugee (Shotgun)",
	Class = "npc_citizen",
	Weapons = {"weapon_shotgun"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REFUGEE, SquadName = SquadRebel},
	Category = CategoryRefugee
}
list.Set( "NPC", "npc_refugee_shotgun", NPC )

local NPC = { Name = "Refugee (AR2)",
	Class = "npc_citizen",
	Weapons = {"weapon_ar2"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REFUGEE, SquadName = SquadRebel},
	Category = CategoryRefugee
}
list.Set( "NPC", "npc_refugee_ar2", NPC )

local NPC = { Name = "Refugee (RPG)",
	Class = "npc_citizen",
	Weapons = {"weapon_rpg"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REFUGEE, SquadName = SquadRebel},
	Category = CategoryRefugee
}
list.Set( "NPC", "npc_refugee_rpg", NPC )

--[[---------------------------------------------------------------------------
	Rebel Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Rebel (Unarmed)",
	Class = "npc_citizen",
	Weapons = {""},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebel
}
list.Set( "NPC", "npc_rebel_unarmed", NPC )

local NPC = { Name = "Rebel (Pistol)",
	Class = "npc_citizen",
	Weapons = {"weapon_pistol"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebel
}
list.Set( "NPC", "npc_rebel_pistol", NPC )

local NPC = { Name = "Rebel (SMG)",
	Class = "npc_citizen",
	Weapons = {"weapon_smg1"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebel
}
list.Set( "NPC", "npc_rebel_smg", NPC )

local NPC = { Name = "Rebel (Shotgun)",
	Class = "npc_citizen",
	Weapons = {"weapon_shotgun"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebel
}
list.Set( "NPC", "npc_rebel_shotgun", NPC )

local NPC = { Name = "Rebel (AR2)",
	Class = "npc_citizen",
	Weapons = {"weapon_ar2"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebel
}
list.Set( "NPC", "npc_rebel_ar2", NPC )

local NPC = { Name = "Rebel (RPG)",
	Class = "npc_citizen",
	Weapons = {"weapon_rpg"},
	Health = HealthRebel,
	SpawnFlags = SF_CITIZEN_RANDOM_HEAD,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebel
}
list.Set( "NPC", "npc_rebel_rpg", NPC )

--[[---------------------------------------------------------------------------
	Rebel Medic Team
---------------------------------------------------------------------------]]--

local NPC = { Name = "Rebel Medic (Unarmed)",
	Class = "npc_citizen",
	Weapons = {""},
	Health = HealthRebelMedic,
	SpawnFlags = SERVER and bit.bor( SF_NPC_DROP_HEALTHKIT, SF_CITIZEN_MEDIC ) or nil,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebelMedic
}
list.Set( "NPC", "npc_rebel_medic_unarmed", NPC )

local NPC = { Name = "Rebel Medic (Pistol)",
	Class = "npc_citizen",
	Weapons = {"weapon_pistol"},
	Health = HealthRebelMedic,
	SpawnFlags = SERVER and bit.bor( SF_NPC_DROP_HEALTHKIT, SF_CITIZEN_MEDIC ) or nil,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebelMedic
}
list.Set( "NPC", "npc_rebel_medic_pistol", NPC )

local NPC = { Name = "Rebel Medic (SMG)",
	Class = "npc_citizen",
	Weapons = {"weapon_smg1"},
	Health = HealthRebelMedic,
	SpawnFlags = SERVER and bit.bor( SF_NPC_DROP_HEALTHKIT, SF_CITIZEN_MEDIC ) or nil,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebelMedic
}
list.Set( "NPC", "npc_rebel_medic_smg", NPC )

local NPC = { Name = "Rebel Medic (Shotgun)",
	Class = "npc_citizen",
	Weapons = {"weapon_shotgun"},
	Health = HealthRebelMedic,
	SpawnFlags = SERVER and bit.bor( SF_NPC_DROP_HEALTHKIT, SF_CITIZEN_MEDIC ) or nil,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebelMedic
}
list.Set( "NPC", "npc_rebel_medic_shotgun", NPC )

local NPC = { Name = "Rebel Medic (AR2)",
	Class = "npc_citizen",
	Weapons = {"weapon_ar2"},
	Health = HealthRebelMedic,
	SpawnFlags = SERVER and bit.bor( SF_NPC_DROP_HEALTHKIT, SF_CITIZEN_MEDIC ) or nil,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebelMedic
}
list.Set( "NPC", "npc_rebel_medic_ar2", NPC )

local NPC = { Name = "Rebel Medic (RPG)",
	Class = "npc_citizen",
	Weapons = {"weapon_rpg"},
	Health = HealthRebelMedic,
	SpawnFlags = SERVER and bit.bor( SF_NPC_DROP_HEALTHKIT, SF_CITIZEN_MEDIC ) or nil,
	KeyValues = {citizentype = CT_REBEL, SquadName = SquadRebel},
	Category = CategoryRebelMedic
}
list.Set( "NPC", "npc_rebel_medic_rpg", NPC )