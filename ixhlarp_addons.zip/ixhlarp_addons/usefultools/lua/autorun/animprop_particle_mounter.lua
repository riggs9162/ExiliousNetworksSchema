//Garry's Mod 13 no longer auto-adds particles from any game other than the first one you have mounted, which is usually Half-Life 2.
//This code will add the particles manually, allowing them to work regardless of what order your games are mounted in.

game.AddParticles("particles/teleport_status.pcf")
game.AddParticles("particles/flag_particles.pcf")