--[[
    
     _   _  _  _    _                    _           _                        
    | | | || || |  (_)                  | |         | |                       
    | | | || || |_  _  _ __ ___    __ _ | |_   ___  | |      ___    __ _  ___ 
    | | | || || __|| || '_ ` _ \  / _` || __| / _ \ | |     / _ \  / _` |/ __|
    | |_| || || |_ | || | | | | || (_| || |_ |  __/ | |____| (_) || (_| |\__ \
     \___/ |_| \__||_||_| |_| |_| \__,_| \__| \___| \_____/ \___/  \__, ||___/
                                                                    __/ |     
                                                                   |___/      
    
    
]]--





ULogs.AddGMType( 1, "Sandbox" )
ULogs.AddGMType( 2, "DarkRP" )
ULogs.AddGMType( 3, "TTT" )
ULogs.AddGMType( 4, "Murder" )
ULogs.AddGMType( 5, "Admin" )
ULogs.AddGMType( 6, "Cinema" )



